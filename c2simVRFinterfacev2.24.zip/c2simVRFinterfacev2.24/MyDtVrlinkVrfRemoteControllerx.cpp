// added missing class from MAK for VRF5.0.1a

#include "MyDtVrlinkVrfRemoteController.h"

