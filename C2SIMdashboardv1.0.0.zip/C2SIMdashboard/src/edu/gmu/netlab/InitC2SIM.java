/*----------------------------------------------------------------*
|   Copyright 2009-2023 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/
package edu.gmu.netlab;

/**
 * @author mpullen
 */
import javax.swing.JFileChooser;
import com.jaxfront.core.util.URLHelper;
import java.io.*;
import edu.gmu.c4i.c2simclientlib2.*;

/**
 * build or reads a new C2SIM Initialize document
 */

public class InitC2SIM {
    
    C2SIMdashboard bml = C2SIMdashboard.bml;
    private String documentType = "InitC2SIM";
    private String serverStatus = "UNKNOWN";
    C2SIMHeader c2simHeader = new C2SIMHeader();
    
    // constructor (empty)
    public InitC2SIM() {}
    
        /**
     * load a new C2SIM Initialize document from file system
     * returns true if successful
     */
    String submitInitFSC2SIM()
    {
        JFileChooser xmlFc = //XML file
            new JFileChooser(bml.getSchemaDirectory());	
        xmlFc.setDialogTitle("Enter the Initialization XML file name");
        xmlFc.showOpenDialog(bml);
        if(xmlFc.getSelectedFile() == null)return "file not found";

        // open connection to REST server
        if(bml.submitterID.length() == 0) {
            bml.showInfoPopup( 
                "cannot push C2SIM Init - submitterID required", 
                "C2SIM Init Push Message");
            return "cannot push C2SIM Init - submitterID required";
        }

        // read XML from file
        String pushInitInputString = 
            bml.readAnXmlFile(xmlFc.getSelectedFile().getPath());

        // display and send the input
        if(bml.debugMode){
            int pushC2Len = pushInitInputString.length();
            if(pushC2Len > 1200)pushC2Len = 1200;
            bml.printDebug("PUSH C2SIM INITIALIZE XML:" +
                pushInitInputString.substring(0,pushC2Len));
        }
        String pushInitResponseString = "";
        pushInitResponseString = 
            bml.ws.sendC2simREST(
                pushInitInputString,
                "INFORM",
                bml.c2simProtocolVersion);
        
        // display result
        bml.showInfoPopup( 
            pushInitResponseString, 
            "C2SIM Initialize Push Message");
        
        return pushInitResponseString;
        
    }// end submitInitFSC2SIM()
        
    /**
     * send C2SIM command e.g. SHARE (do at end of Initialize)
     */
    String pushC2simServerControl(String command)
    {
        // open connection to REST server
        if(bml.submitterID.length() == 0) {
            bml.showInfoPopup( 
                "cannot push C2SIM server control - submitter ID required", 
                "C2SIM Server Control Push Message");
            return "cannot push C2SIM server control - submitter ID required";
        }
        
        // start REST connection using performative for Initialize
        C2SIMClientREST_Lib c2simClient = bml.ws.newRESTLib("INFORM");
        c2simClient.setHost(bml.serverName);
        if(bml.debugMode)bml.printDebug("C2SIM Order/Init Host:"+bml.serverName);
        c2simClient.setSubmitter(bml.submitterID);
        if(bml.debugMode)bml.printDebug("C2SIM Order/Init Submitter:"+bml.submitterID);
        c2simClient.setPath("C2SIMServer/c2sim");
      
        // get the password and check that it has content
        if(bml.serverPassword.length() == 0 &&
            !command.equals("STATUS") &&
            !command.equals("QUERYINIT")) {
            bml.showInfoPopup( 
                "cannot push C2SIM Init - password required", 
                "C2SIM Server Control Push Message");
            return "cannot push C2SIM server control - password required";
        }

        // send the command
        String pushShareResponseString = "";
        try{
            pushShareResponseString = 
                c2simClient.c2simCommand(command,bml.serverPassword,"","");
        } catch (C2SIMClientException bce) {
            bml.showErrorPopup(
                "exception pushing C2SIMserver control:" +
                    bce.getMessage()+" cause:" + bce.getCauseMessage(), 
                "C2SIM Server Control Push Message");
            bml.printError("RESPONSE:" + pushShareResponseString);
            bce.printStackTrace();
            return pushShareResponseString;
        }

        // display and return result
        if(bml.debugMode)bml.printDebug("The C2SIM server control push result length : " +
                pushShareResponseString.length());
                //+ "XML:"+  pushShareResponseString + "|");
        if(!command.equals("STATUS") && !command.equals("QUERYINIT")) {
            int startStatus = pushShareResponseString.indexOf("State set to ") + 13;
            serverStatus = pushShareResponseString.substring(startStatus);
        }
        // initial startup (status showing UNKNOWN) - extract and post status
        else if(serverStatus.equals("UNKNOWN")){
            int startOfState, endOfState;
            int sessionIndex = pushShareResponseString.indexOf("<sessionState>");
            if(sessionIndex > 0){
                startOfState = sessionIndex + 14;
                endOfState = pushShareResponseString.indexOf("</sessionState>");
            }
            else
            {
                startOfState = pushShareResponseString.indexOf("<SessionState>") + 14;
                endOfState = pushShareResponseString.indexOf("</SessionState>");
            }
            // pull the state out of reply
            if (startOfState > 14) {serverStatus = 
                pushShareResponseString.substring(startOfState, endOfState);
            }
        }
        return pushShareResponseString;
        
    }// end pushC2simServerControl()
    
    /**
     * send C2SIM command e.g. SHARE (do at end of Initialize)
     */
    String pushC2simServerInput(String command) {
        return pushC2simServerInput(command,"","",""); 
    }
    String pushC2simServerInput(String command,String parm) {
        return pushC2simServerInput(command,parm,"","");
    }
    String pushC2simServerInput(
        String command, String parm1, String parm2, String parm3)
    {
        // open connection to REST server
        if(bml.debugMode)bml.printDebug("server input:" +
            command + " " + parm1 + " " + parm2 + " " + parm3);
        if(bml.submitterID.length() == 0) {
            bml.showInfoPopup( 
                "cannot push C2SIM server input - submitter ID required", 
                "C2SIM Server Control Push Message");
            return "cannot push C2SIM server control - submitter ID required";
        }
        
        // start REST connection using performative for Initialize
        C2SIMClientREST_Lib c2simClient = bml.ws.newRESTLib("INFORM");
        c2simClient.setHost(bml.serverName);
        if(bml.debugMode)bml.printDebug("C2SIM Order/Init Host:"+bml.serverName);
        c2simClient.setSubmitter(bml.submitterID);
        if(bml.debugMode)bml.printDebug("C2SIM Order/Init Submitter:"+bml.submitterID);
        c2simClient.setPath("C2SIMServer/c2sim");

        // send the command
        String pushShareResponseString = "";
        try{
            pushShareResponseString = 
                c2simClient.c2simCommand(command,parm1,parm2,parm3);
        } catch (C2SIMClientException bce) {
            bml.showErrorPopup(
                "exception pushing C2SIMserver input:" +
                    bce.getMessage()+" cause:" + bce.getCauseMessage(), 
                "C2SIM Server Input Push Message");
            bml.printError("RESPONSE:" + pushShareResponseString);
            bce.printStackTrace();
            return pushShareResponseString;
        }
         
        // display and return result
        if(bml.debugMode)bml.printDebug("The C2SIM server input push result length : " +
                pushShareResponseString.length() + " XML:" +
                pushShareResponseString + "|");
        return pushShareResponseString;
        
    }// end pushC2simServerInput()
    
    /**
     * server control functions
     */
    String pushShareC2SIM(){return pushC2simServerControl("SHARE");}
    String pushInitializeC2SIM(){return pushC2simServerControl("INITIALIZE");}
    String pushResetC2SIM(){return pushC2simServerControl("RESET");}
    String pushStartC2SIM(){return pushC2simServerControl("START");}
    String pushPauseC2SIM(){return pushC2simServerControl("PAUSE");}
    String pushResumeC2SIM(){return pushC2simServerControl("RESUME");}
    String pushStopC2SIM(){return pushC2simServerControl("STOP");}
    String pushEditC2SIM(){return pushC2simServerControl("EDIT");}
    
    /**
     * server record and playback controls
     * @return 
     */
    String pushServerRecStart(){return pushC2simServerInput("STARTREC");}
    String pushServerRecPause(){return pushC2simServerInput("PAUSEREC");}
    String pushServerRecRestart(){return pushC2simServerInput("RESTARTREC");}
    String pushServerRecStop(){return pushC2simServerInput("STOPREC");}
    String pushServerRecGetStatus() {return pushC2simServerInput("GETRECSTAT");}
    String pushServerPlayPause(){return pushC2simServerInput("PAUSEPLAY");}
    String pushServerPlayRestart(){return pushC2simServerInput("RESTARTPLAY");}
    String pushServerPlayStop(){return pushC2simServerInput("STOPPLAY");}
    String pushServerPlayGetStatus() {return pushC2simServerInput("GETPLAYSTAT");}
    String getSimTimeMult() {return pushC2simServerInput("GETSIMMULT");}
    String getPlayTimeMult() {return pushC2simServerInput("GETPLAYMULT");}
    
    // status check; can initiate a late joiner initialization
    String pushStatusC2SIM(){
                
        String response = pushC2simServerControl("STATUS");
        //bml.sendSystemMessage("GETPLAYSTAT");
        //bml.sendSystemMessage("GETRECSTAT");
        return response;
        
    }// end pushStatusC2SIM()
    
    // status check to initialize server recording/playback button
    String pushStatusPlayback(){
                
        // server recording status
        String response = pushC2simServerInput("GETPLAYSTAT");
        if(response.contains("NO_PLAYBACK IN PROGRESS"))
            return "NO_PLAYBACK IN PROGRESS";
        if(response.contains("PLAYBACK_RUNNING"))
            return "PLAYBACK_RUNNING";
        if(response.contains("PLAYBACK_PAUSED"))
            return "PLAYBACK_PAUSED";
        return "NOT FOUND";
                    
    }// end pushStatusPlayback()
     
    String pushStatusRecord(){          
        // server recording status
        String response = pushC2simServerInput("GETRECSTAT");
        if(response.contains("NOT_RECORDING"))
            return "NOT_RECORDING";
        if(response.contains("RECORDING_IN_PROGRESS"))
            return "RECORDING_IN_PROGRESS";
        if(response.contains("RECORDING_PAUSED"))
            return "RECORDING_PAUSED";
        return "NOT FOUND";
                    
    }// end pushStatusRecord()
    
}// end class InitC2SIM
