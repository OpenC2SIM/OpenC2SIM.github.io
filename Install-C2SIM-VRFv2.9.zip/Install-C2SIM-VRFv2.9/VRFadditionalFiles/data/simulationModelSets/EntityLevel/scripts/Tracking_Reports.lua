-- A background process to send tracking reports.
-- Sent in a text report, with format
-- TRACKING "entity name" <lat in deg.> <lon in deg>
-- There must be 1 and only 1 space between TRACKING and the
-- quoted entity name.

-- Some basic VRF Utilities defined in a common module.
require "vrfutil"

-- Called when the task first starts. Never called again.
function init()
   -- Set the tick period for this script.
   vrf:setTickPeriod(20)
end

-- Called each tick while this task is active.
function tick()
   if this:getForceType() == "Friendly" then
      reportString = string.format("POSITION \"%s\" %f %f",
          this:getName(), math.deg(this:getLocation3D():getLat()), 
            math.deg(this:getLocation3D():getLon()))
   --   printWarn(reportString)
      vrf:sendReport("text-report", {text = reportString})
   end
end
