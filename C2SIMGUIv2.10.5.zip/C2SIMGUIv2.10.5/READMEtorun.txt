The BMLC2GUI can be run by invoking in this directory

for Linux and MacOSX: ./runGUI

for Microsoft Windows: runC2SIMGUI.bat

