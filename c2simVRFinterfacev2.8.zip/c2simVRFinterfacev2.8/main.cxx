/*******************************************************************************
** Copyright (c) 2002 MAK Technologies, Inc.
** All rights reserved.
*******************************************************************************/
/*******************************************************************************
** $RCSfile: main.cxx,v $ $Revision: 1.13 $ $State: Exp $
*******************************************************************************/
//** MODIFIED 1Mar2019 by GMU C4I & Cyber Lab for c2simVRF

// c2simVRFv2.8 updated to use C++ClientLibv4.7.0.0 5JMar2020

#include <iostream>
#include <cstring>
#include <string>
#include "textIf.h"
#include "remoteControlInit.h"

// VR-Forces headers
#include <vrfMsgTransport/vrfMessageInterface.h>
#include <vrfcontrol/vrfRemoteController.h>

// IP address and port of C2SIM (BML) server
std::string serverAddress = "10.2.10.30";
std::string stompPort = "61613"; // standard server STOMP port
std::string restPort = "8080";   // normal C2SIM REST port

// local configuration defaults
int reportInterval = 30; // in seconds 
std::string clientId = "VRFORCES";
std::string skipInitialize = "0";
std::string useIbml = "0";
std::string sendRedTracking = "0";
std::string vrfLocalAddress = "127.0.0.1";
char* vrfAddr = new char[15];

// provides STOMP interface and build VRForces commands
#include "C2SIMinterface.h"

// Thread functionality
#include <thread>

static int timesCalled = 0;

int main(int argc, char** argv)
{
	// extract up to 9 arguments: 
	// IP address, REST port number, STOMP port number, clientID, 
	// skipInitialize, useIbml, sendRedTracking, VRForces Local IP Address, reportInterval
	std::cout << "Starting VR-Forces C2SIM Interface v2.8 compatible VR-Forcesv4.7\n";
	if (argc < 2)
		std::cout << "using default server IP address:" << serverAddress << "\n";
	else
		serverAddress = argv[1];
	if (argc < 3)
		std::cout << "using default REST port:" << restPort << "\n";
	else
		restPort = argv[2];
	if (argc < 4)
		std::cout << "using default STOMP port:" << stompPort << "\n";
	else
		stompPort = argv[3];
	if (argc < 5)
		std::cout << "using default client ID:" << clientId << "\n";
	else
		clientId = argv[4];
	if (argc < 6)
		std::cout << "defaulting to require initialization sequence\n";
	else
		skipInitialize = argv[5];
	if (argc < 7)
		std::cout << "defaulting to C2SIM_v9_SMX_LOX schema\n";
	else {
		useIbml = argv[6];
		if (useIbml == "1")std::cout << "expecting IBML09 input\n";
		else std::cout << "expecting C2SIMv9 input\n";
	}
	if (argc < 8)
		std::cout << "defaulting to not sending red tracking reports\n";
	else {
		sendRedTracking = argv[7];
		if(sendRedTracking == "1")std::cout << "sending red tracking reports\n";
		else std::cout << "not sending red tracking reports\n";
	}
	if (argc < 9)
		std::cout << "VRForces address defaulting to " << vrfLocalAddress << "\n";
	else 
		vrfLocalAddress = argv[8];
	std::strcpy(vrfAddr, vrfLocalAddress.c_str());
	if (argc < 10)
		std::cout << "C2SIM report interval defaulting to " << reportInterval << "\n";
	else
		reportInterval = stoi(argv[9]);

	// arguments for VRForces
	// command line: --disVersion 7 --deviceAddress 127.0.0.1 --disPort 3000 -a 3001 -s 1 -x 1
	char* vrfArgv[13] =
	{ "bin64\\c2simVRF", "--disVersion", "7", "--deviceAddress", vrfAddr, //"127.0.0.1",
		"--disPort", "3000", "-a", "3002", "-s", "1", "-x", "1" };
	std::cout << "VR-Forces arguments:";
	for (int i = 1; i < 13; i+=2)std::cout << vrfArgv[i] << " " << vrfArgv[i+1] << "|";
	std::cout << "\n";
	
	// Create initializer object used to provide initialization data to the
	// exercise connection, configured through command line arguments.
	DtRemoteControlInitializer appInitializer(13, vrfArgv);
	appInitializer.parseCmdLine();
	
	// Create the controller
	DtVrfRemoteController* controller = new DtVrfRemoteController();
	
	// Create an exercise connection
	DtExerciseConn* exConn = new DtExerciseConn(appInitializer);
	controller->init(exConn);
	
	// Create a C2SIM controller to read orders and translate them for VRF
	C2SIMinterface* c2simInterface =
		new C2SIMinterface(controller, serverAddress, stompPort, restPort, clientId,
			useIbml == "1");
	
	// Create our text interface so we can enter text commands.
	DtTextInterface* textIf = 
		new DtTextInterface(controller, serverAddress, restPort, clientId,
			useIbml == "1",sendRedTracking == "1");
	
	// Start a thread to read from STOMP and generate VRForces commands
	std::thread t1(&C2SIMinterface::readStomp, textIf, c2simInterface,
		skipInitialize == "1", clientId, reportInterval);

	// start a thread to generate reports (must start after ojects are created)
	std::thread t3(&C2SIMinterface::reportGenerator);
	
	/*Processing: read stdin and call drainInput.
		Calling drainInput() ensures that the controller receives
		necessary feedback from VR-Forces backend applications.
	*/
	while (!textIf->timeToQuit())
	{ 
		textIf->readCommand();
		exConn->clock()->setSimTime(exConn->clock()->elapsedRealTime());
		exConn->drainInput();
		DtSleep(0.1);
	}
	
	// shutdown
	t1.join();
	delete textIf;
	delete controller;
	delete exConn;
   
	return 0;
}

