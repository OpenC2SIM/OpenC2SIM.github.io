/*----------------------------------------------------------------*
|     Copyright 2020 Networking and Simulation Laboratory         |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for academic purposes is hereby  |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

// c2simVRF 2.8 consistent with C2SIM_SMX_LOX_v11.xsd

#include "C2SIMxmlHandler.h"

using namespace xercesc;

// conversion factor
const static double degreesToRadians = 57.2957795131L;

// root of the XML document
std::string rootTag = "";

// storage for order data

// strings to manipulate XML parsing
std::string latestTag;
std::string startTag;
std::string endTag;
std::string previousTag;
std::string dataText;

// type of message we are parsing
enum parsingType {
	NONE,
	INIT,
	SYSTEM,
	DOMAINTYPE,
	C2SIMORDER,
	C2SIMREPORT,
	IBMLORDER,
	IBMLREPORT
} parsingType_t;

// flags to control parsing flow
bool skipThisDocument = false;
bool parsingC2SIMTask = false;
bool parsingManeuverWarfareTask = false;

// strings extracted from XML
std::string taskersIntent;
std::string dateTime;
std::string taskeeUuid;
std::string actionTaskActivityCode;
std::string latitude;
std::string longitude;
std::string elevation;
std::string latitudes[MAXPOINTS]; // each element is a latitude string
std::string longitudes[MAXPOINTS];// each element is a longitude string
std::string elevations[MAXPOINTS];// each element is an elevation string

// flags to indicate we've found a particular order string
bool foundRootTag = false;
bool foundIbmlOrderRootTag = false;
bool foundFinalTag = false;
bool parsingEntity = false;
bool parsingForceSide = false;
bool parsingSystemEntityList = false;
bool parsingSystemCommandTypeCode = false;
bool foundTaskTag = false;
bool foundPerformingEntity = false;
int latitudePointCount = 0;
int longitudePointCount = 0;
int elevationPointCount = 0;
parsingType currentMessageType = NONE;
bool parsingC2simOrder = false;
bool parsingIbmlOrder = false;
bool parsingC2simReport = false;
bool parsingIbmlReport = false;
bool parsingC2simInitialize = false;
bool parsingSystemMessage = false;
bool parseIbml;
int actorCount = 0; // actors in SystemEntityList
std::string orderFromSender = "";
std::string orderToReceiver = "";

// data from the SystemEntityList of a C2SIMInitialize message
std::vector<std::string> actors;

// Tasks for Orders
// array of all tasks received in orders
std::string thisOrderUuid = "";
int tasksThisOrder;
Task* thisTask = NULL;
Unit* thisUnit = NULL;
ForceSide* thisForceSide;

// Military Organization data for Units
static Unit* militaryOrgUnits;

// Simulation Control data
// UNINITIALIZED, INITIALIZING, INITIALIZED, RUNNING, PAUSED
static std::string systemState = "";

// constructor
C2SIMxmlHandler::C2SIMxmlHandler(bool useIbmlRef)
{
	// copy parameter value
	parseIbml = useIbmlRef;

	// initialize strings to zero length
	latestTag = "";
	startTag = "";
	endTag = "";
	previousTag = "";
	dataText = "";
	taskersIntent = "";
	dateTime = "";
	taskeeUuid = "";
	actionTaskActivityCode = "";
	latitude = "";
	longitude = "";
	elevation = "";
	for (int i = 0; i < MAXPOINTS; ++i) {
		latitudes[i] = "";
		longitudes[i] = "";
		elevations[i] = "";
	}
	orderFromSender = "";
	orderToReceiver = "";

	// initialize unit and Task maps
	unitMap; unitNameMap;
	thisUnit = NULL;
	actorCount = 0;
	taskMap; taskNameMap;

	// initialize task index
	tasksThisOrder = 0;

}// end constructor

// destructor
C2SIMxmlHandler::~C2SIMxmlHandler()
{
}// end destructor


// print an error impotant enough to catch attention
// with a line of * on each side
void C2SIMxmlHandler::displayError(std::string errorText) {
	std::cout << std::string(errorText.length(), '*') << "\n";
	std::cout << errorText << "\n";
	std::cout << std::string(errorText.length(), '*') << "\n";
}

std::string C2SIMxmlHandler::getRootTag()
{
	return rootTag;
}

// returns root tag found in latest parse
// if no root tag found this will be empty string
int C2SIMxmlHandler::getMessageType()
{
	return currentMessageType;
}

// returns FromSender from order
std::string C2SIMxmlHandler::getOrderSender() {
	return orderFromSender;
}

// returns ToReceiver from order
std::string C2SIMxmlHandler::getOrderReceiver() {
	return orderToReceiver;
}

// returns superiorUnit for unit
std::string C2SIMxmlHandler::getSuperiorUnit(std::string uuid) {
	Unit* unit = unitMap[uuid];
	if (unit == NULL) return "";
	return unit->superiorUnit;
}

// returns reportFromSender for unit
std::string C2SIMxmlHandler::getReportFromSender(std::string uuid) {
	Unit* unit = unitMap[uuid];
	if (unit == NULL) return "";
	return unit->reportFromSender;
}

// returns reportToReceiver for unit
std::string C2SIMxmlHandler::getReportToReceiver(std::string uuid) {
	Unit* unit = unitMap[uuid];
	if (unit == NULL) return "";
	return unit->reportToReceiver;
}

// returns pointer to the Unit associated with a UUID
Unit* C2SIMxmlHandler::getUnit(std::string uuid){
	return unitMap[uuid];
}

// returns pointer to to Unit associated with a name
Unit* C2SIMxmlHandler::getUnitByName(std::string name){
	return unitNameMap[name];
}

// adds a new Unit to unitMap
// returns false if unit already eists; true otherwise
boolean C2SIMxmlHandler::addUnit(Unit* newUnit){
	if (unitMap[newUnit->uuid] != NULL){
		displayError("ERROR - UNITID:" + newUnit->uuid +
			" ALREADY ENTERED - DUPLICATES NOT ALLOWED");
		return false;
	}
	unitMap[newUnit->uuid] = newUnit;
	return true;
}

// adds a unit pointer to the the unitNameMap using name in the unit as key
// returns false if unit already exists; true otherwise
boolean C2SIMxmlHandler::addUnitByName(Unit* newUnit){
	if (unitNameMap[newUnit->name] != NULL)
		if (unitNameMap[newUnit->name]->name != "") {
			displayError("ERROR - UNIT NAME:" + newUnit->name +
				" ALREADY ENTERED - DUPLICATES NOT ALLOWED");
			return false;
		}
	unitNameMap[newUnit->name] = newUnit;
	return true;
}

// returns true if the unitMap is empty
boolean C2SIMxmlHandler::unitMapIsEmpty(){
	return unitMap.empty();
}

// builds an empty Unit with UUID from parameter
Unit* C2SIMxmlHandler::makeEmptyUnit(std::string UUID) {
	Unit* unit = new Unit;
	unit->uuid = UUID;
	unit->name = "";
	unit->vrfDtString = "";
	unit->opStatusCode = "";
	unit->strengthPercent = "";
	unit->hostilityCode = "";
	unit->echelon = "";
	unit->superiorUnit = "";
	unit->latitude = "";
	unit->longitude = "";
	unit->elevationAgl = "1000.";
	unit->directionPhi = "";
	unit->directionPsi = "";
	unit->directionTheta = "";
	unit->symbolId = "";
	unit->disEntityType = "";
	unit->forceSideUuid = "";
	unit->systemName = "";
	unit->aggregateName = "";
	unit->vrfObjectHasBeenCreated = false;
	unit->reportFromSender = "";
	unit->reportToReceiver = "";
	return unit;
}

// returns iterator begin() for unitMap
std::map<std::string, Unit*>::iterator C2SIMxmlHandler::getUnitMapBegin(){
	return unitMap.begin();
}

// returns iterator end() for unitMap
std::map<std::string, Unit*>::iterator C2SIMxmlHandler::getUnitMapEnd(){
	return unitMap.end();
}

// builds an empty ForceSide with UUID from parameter
ForceSide* C2SIMxmlHandler::makeEmptyForceSide(std::string Uuid) {
	ForceSide* forceSide = new ForceSide;
	forceSide->uuid = Uuid;
	forceSide->HostilityCode = "";
	return forceSide;
}

// build an empty Task with UUID from parameter
Task* C2SIMxmlHandler::makeNewTask(){
	Task* newTask = new Task;
	newTask->taskUuid = "";
	newTask->taskName = "";
	newTask->orderUuid;
	newTask->taskRouteDtString = "";
	newTask->performingEntity;
	newTask->affectedEntity;
	newTask->taskeeUuid;
	newTask->actionTaskActivityCode;
	newTask->dateTime;
	newTask->latitudePointCount = 0;
	newTask->longitudePointCount = 0;
	newTask->elevationPointCount = 0;
	newTask->pickupPointName = "";
	newTask->dropoffPointName = "";
	newTask->returnPointName = "";
	newTask->scriptedTaskUuid = NULL;
	return newTask;
}

// adds a Task to the taskMap
// returns false if unit already exists; true otherwise
boolean C2SIMxmlHandler::addTask(Task* newTask){
	if (taskMap[newTask->taskUuid] != NULL){
		displayError("ERROR - TASKID:" + newTask->taskUuid + 
			" ALREADY ENTERED - DUPLICATES NOT ALLOWED");
		return false;
	}
	taskMap[newTask->taskUuid] = newTask;
	if (newTask->taskName != "")
		taskNameMap[newTask->taskName] = newTask;
	newTask->orderUuid = thisOrderUuid;
	return true;
}

// returns the task with parameter UUID associated with thisOrderUUID
Task* C2SIMxmlHandler::getTask(std::string taskUuid){
	return taskMap[taskUuid];
}

// returns the task with iterator taskIt associated with thisOrderUUID
Task* C2SIMxmlHandler::getTask(std::map<std::string, Task*>::iterator taskIt){
	return taskIt->second;
}

// returns the task with parameter name associated with thisOrderUUID
Task* C2SIMxmlHandler::getTaskByName(std::string name){
	return taskNameMap[name];
}

// returns iterator begin() for unitMap
std::map<std::string, Task*>::iterator C2SIMxmlHandler::getTaskMapBegin(){
	return taskMap.begin();
}

// returns iterator end() for unitMap
std::map<std::string, Task*>::iterator C2SIMxmlHandler::getTaskMapEnd(){
	return taskMap.end();
}

// returns true if C2SIM OrderBody tag has been found
bool C2SIMxmlHandler::isC2simOrder(){
	return parsingC2simOrder;
}

// returns true if IBML Order tag has been found
bool C2SIMxmlHandler::isIbmlOrder(){
	return parsingIbmlOrder;
}

// returns true if C2SIM ReportBody tag has been found
bool C2SIMxmlHandler::isC2simReport(){
	return parsingC2simReport;
}

// returns true if IBML Report tag has been found
bool C2SIMxmlHandler::isIbmlReport(){
	return parsingIbmlReport;
}

// returns UUID associated with unitName in the unitMap
std::string C2SIMxmlHandler::getUuid(std::string unitName) {
	Unit* unit = getUnitByName(unitName);
	static std::string returnCode = "";
	if (unit != NULL)
		returnCode = unit->uuid;
	return returnCode;
}

// returns hostility associated with unitName in the unitMap
std::string C2SIMxmlHandler::getHostilityCode(std::string unitName) {
	Unit* unit = getUnitByName(unitName);
	static std::string returnCode = "";
	if (unit != NULL)
		returnCode = unit->hostilityCode;
	return returnCode;
}

// returns opStatusCode associated with unitName in the unitMap
std::string C2SIMxmlHandler::getOpStatusCode(std::string unitName){
	Unit* unit = getUnitByName(unitName);
	static std::string returnCode = "";
	if (unit != NULL)
		returnCode = unit->opStatusCode;
	return returnCode;
}

// returns strengthPercent associated with unitName in the unitMap
std::string C2SIMxmlHandler::getStrength(std::string unitName){
	Unit* unit = getUnitByName(unitName);
	static std::string returnCode = "";
	if (unit != NULL)
		returnCode = unit->strengthPercent;
	return returnCode;
}

// returns aggregate name associated with unit name in the unitMap
std::string C2SIMxmlHandler::getAggregateUnitName(std::string unitName) {
	Unit* unit = unitNameMap[unitName];
	if (unit == NULL)return "";
	return unit->aggregateName;
}

// returns value of taskersIntent
std::string C2SIMxmlHandler::getTaskersIntent()
{
	return taskersIntent;
}

// returns value of dataTime
std::string C2SIMxmlHandler::getDateTime()
{
	return dateTime;
}

// returns value of taskeeUuid
std::string C2SIMxmlHandler::getTaskeeUuid()
{
	return taskeeUuid;
}

// returns value of affectedEntity UUID
std::string C2SIMxmlHandler::getAffectedEntity(Task* task)
{
	return task->affectedEntity;
}

// returns value of getActionTaskActivityCode
std::string C2SIMxmlHandler::getActionTaskActivityCode()
{
	return actionTaskActivityCode;
}
 
// returns the count of Units from Military_Organization message
int C2SIMxmlHandler::getNumberOfUnits() {
	return unitMap.size();
}// end C2SIMxmlHandler::getNumberOfUnits() 


// returns the count of tasks for an order
int C2SIMxmlHandler::getNumberOfTasksThisOrder() {
	return tasksThisOrder;
}// end C2SIMxmlHandler::getNumberOfTasksThisOrder()


// return controlAction from last C2SIM_Simulation_Control message
std::string C2SIMxmlHandler::getSystemState() {
	return systemState;
}


// called by C2SIMinterface to start parse 
// resets for a new C2SIM document
void C2SIMxmlHandler::startC2SIMParse()
{
	// reset root tag
	rootTag = "";

	// reset logical flags and counts
	skipThisDocument = false;
	parsingC2SIMTask = false;
	parsingManeuverWarfareTask = false;
	skipThisDocument = false;
	foundRootTag = false;
	foundFinalTag = false;
	parsingEntity = false;
	parsingForceSide = false;
	parsingSystemEntityList = false;
	parsingSystemCommandTypeCode = false;
	parsingC2simOrder = false;
	parsingIbmlOrder = false;
	parsingC2simReport = false;
	parsingIbmlReport = false;
	parsingC2simInitialize = false;
	parsingSystemMessage = false;
	currentMessageType = NONE;
	actorCount = 0;
	tasksThisOrder = 0;
	orderFromSender = "";
	orderToReceiver = "";
	thisTask = NULL;
	thisUnit = NULL;
}

// transcode XMLCh* to char*, copy that to string output 
// then release the transcoded copy
// this seems inefficient but its too hard to
// keep track of and release multiple encodings
void C2SIMxmlHandler::copyXMLChLessNs(std::string &output, const XMLCh* const input) {
	char* handoff = XMLString::transcode(input);
	output = handoff;
	int colonPosition = output.find(':');
	if (colonPosition != std::string::npos)
		output = output.substr(colonPosition + 1);
	XMLString::release(&handoff);
}

// called at beginning of new XML doc
void C2SIMxmlHandler::startDocument()
{
}

// called at end of parsing XML doc
void C2SIMxmlHandler::endDocument()
{
}

// called with tag at beginning of an element
void C2SIMxmlHandler::startElement(const XMLCh* const name,
	AttributeList& attributes)
{
	if (skipThisDocument)return;

	// copy tag name parameter to startTag
	copyXMLChLessNs(startTag, name);
	//std::cout << "STARTTAG:" << startTag << "\n";
	
	// copy startTag to latestTag
	previousTag = latestTag;
	latestTag = startTag;

	// check for root tag
	if (!foundRootTag){

		rootTag = startTag;

		// could be IBML09
		if (parseIbml) {
			if (latestTag == "OrderPushIBML") {
				parsingIbmlOrder = true;
				foundRootTag = true;
				tasksThisOrder = 0;
				std::cout << "parsing IBML09 order\n";
				return;
			}
			if (latestTag == "BMLReport") {
				parsingIbmlReport = true;
				foundRootTag = true;
				std::cout << "parsing IBML09 report\n";
				return;
			}
			displayError("ERROR - FOUND UNEXPECTED ROOT TAG:" + latestTag);
			skipThisDocument = true;
			return;
		}

		// all C2SIM root tags should be MessageBody
		if (latestTag != "MessageBody") {
			displayError("ERROR - FOUND UNEXPECTED ROOT TAG:" + latestTag);
			skipThisDocument = true;
			return;
		}
		foundRootTag = true;
		return;
	}

	// next level tags we care about are:
	// - C2SIMInitializationBody
	// - SystemCommandBody
	// - DomainMessageBody with next level:
	//   - OrderBody
	//   - ReportBody
	// 
	// if at this point we are not in process of parsing one of the 
	// four types above, the startElement should be one of the first
	// three; if so, set state to the type we are parsing
	// if not, print the tag and ignore it
	//
	// if last tag was DomainMessageBody, this tag should be one
	// of OrderBody or ReportBody; if so, set the state to the 
	// type we are parsing; if not, print the tag and ignore it
	switch (currentMessageType) {

		// beginning to parse new message
		case NONE:
			if (startTag == "C2SIMInitializationBody") {
				currentMessageType = INIT;
				parsingC2simInitialize = true;
				std::cout << "parsing C2SIM Initialization message\n";
			}
			else if (startTag == "SystemCommandBody") {
				currentMessageType = SYSTEM;
				parsingSystemCommandTypeCode = true;
				std::cout << "received C2SIM System Command message\n";
			}
			else if (startTag == "DomainMessageBody") {
				currentMessageType = DOMAINTYPE;
			}
			else if (startTag == "OrderPushIBML") {
				currentMessageType = IBMLORDER;
				parsingIbmlOrder = true;
			}
			else if (startTag == "BMLReport") currentMessageType = IBMLREPORT;

			// no match, print error and quit parsing
			else if (currentMessageType == NONE){
				std::cout << "ERROR - CAN'T PARSE UNEXPECTED MESSAGE TYPE:" << startTag << "\n";
				skipThisDocument = true;
				return;
			}
			break;

		// parsing C2SIMInitaliation message
		case INIT:
			C2SIMxmlHandler::parseC2simInitialize();
			break;

		// parsing SystemCommand message
		case SYSTEM:
			C2SIMxmlHandler::parseSystemCommand();
			break;

		// just started parsing DomainMessageBody
		// next determine whether Order or Report
		case DOMAINTYPE:
			if (startTag == "OrderBody") {
				currentMessageType = C2SIMORDER;
				parsingC2simOrder = true;
				thisTask = NULL;
				std::cout << "parsing C2SIM Order\n";
				thisOrderUuid = "";
			}
			else if (startTag == "ReportBody") {
				currentMessageType = C2SIMREPORT;
				parsingC2simReport = true;
				std::cout << "parsing C2SIM Report\n";
			}
			else {
				displayError("ERROR - CAN'T PARSE UNEXPECTED DOMAINMESSAGEBODY TYPE:" + startTag);
				skipThisDocument = true;
				return;
			}
			break;

		// parsing C2SIM Order message
		case C2SIMORDER:
			C2SIMxmlHandler::parseC2SIMOrder();
			break;

		// parsing C2SIM Report message
		case C2SIMREPORT:
			skipThisDocument = true;
			break;
			
		// parsing IBML09 Order
		case IBMLORDER:
			C2SIMxmlHandler::parseIBMLOrder();
			break;

		// parsing IBML09 Report
		case IBMLREPORT:
			skipThisDocument = true;
			break;

		// lost track
		default:
			displayError("ERROR - UNEXPECTED STATE PARSING XML : " + currentMessageType);

	}// end switch(currentMessageType)
}// end startElement()


// parse a C2SIM Order
void C2SIMxmlHandler::parseC2SIMOrder() {

	// already found <DomainMessage><OrderBody>
	// here we parse higher-level tags under that which have no data
	// (leaf tags with data are parsed under characters()

	// Task tag starts a new task
	if (latestTag == "Task"){
		parsingC2SIMTask = true;
			
		// increment Tasks count	
		tasksThisOrder++;
		if (thisTask == NULL)
			thisTask = makeNewTask();
		foundTaskTag = true;

		// fill the lat/lon/elev string with zeros
		for (int point = 0; point < MAXPOINTS; ++point) {
			thisTask->latitudes[point] = "0";
			thisTask->longitudes[point] = "0";
			thisTask->elevations[point] = "0";
		}
		return;
	
	}// end Task parse

	// parse ManeuverWarfareTask
	if (latestTag == "ManeuverWarfareTask"){
		if (!parsingC2SIMTask){
			displayError("ERROR - MANEUVERWARFARETASK MUST FOLLOW TASK");
			skipThisDocument = true;
			return;
		}
		parsingManeuverWarfareTask = true;
	}

}// end void C2SIMxmlHandler::parseC2SIMOrder() 

void C2SIMxmlHandler::parseIBMLOrder() {

	// IBML Task
	if (parsingIbmlOrder && startTag == "Task") {

		// increment Tasks count	
		tasksThisOrder++;
		if (thisTask == NULL)
			thisTask = makeNewTask();
		foundTaskTag = true;
		foundPerformingEntity = false;

		// fill the lat/lon/elev string with zeros
		for (int point = 0; point < MAXPOINTS; ++point) {
			thisTask->latitudes[point] = "0";
			thisTask->longitudes[point] = "0";
			thisTask->elevations[point] = "0";
		}
		return;

	}// end IBML Task parse

	// parser may swallow tags without data - force the issue
	if (latestTag == "Unit") {
		characters(L"", 0);
	}
}// end C2SIMxmlHandler::parseIBMLOrder()

// parse a C2SIMInitialize
void C2SIMxmlHandler::parseC2simInitialize() {

	// ForceSide tag
	if (latestTag == "ForceSide") {
		parsingForceSide = true;
		thisForceSide = makeEmptyForceSide(std::string(""));
	}

	// Entity tag
	if (latestTag == "Entity") {
		parsingEntity = true;
		thisUnit = makeEmptyUnit(std::string(""));
		return;
	}

	// SystemEntityList tag
	if (latestTag == "SystemEntityList") {
		parsingSystemEntityList = true;
		actors.clear();
	}
	return;
}

// parse a SystemCommand
void C2SIMxmlHandler::parseSystemCommand() {

	// SystemCommandTypeCode tag
	if (latestTag == "SystemCommandTypeCode")
		parsingSystemCommandTypeCode = true;
	return;
}


// called when last tag of an element of XML has been parsed
void C2SIMxmlHandler::endElement(const XMLCh* const name)
{
	if (skipThisDocument)return;

	// copy name parameter to endTag
	copyXMLChLessNs(endTag, name);
	//std::cout << "ENDTAG:" << endTag << "|\n";
	
	// check whether it is the closing mirror of root tag
	// if so, skip any other input (e.g. translated order from server)
	if (!foundFinalTag) {
		if (parsingC2simInitialize) {

			if(endTag == "C2SIMInitializationBody") {
				foundFinalTag = true;
				skipThisDocument = true;

				// copy HostilityCode from each ForceSide to Unit on that ForceSide
				std::map<std::string, ForceSide*>::iterator forceSideIter;
				for (forceSideIter = forceSideMap.begin();
					forceSideIter != forceSideMap.end();
					++forceSideIter) {
					ForceSide* nextForceSide = forceSideIter->second;

					// scan all Units in the unitMap inserting hostility
					std::map<std::string, Unit*>::iterator unitIter;
					for (unitIter = unitMap.begin();
						unitIter != unitMap.end();
						++unitIter) {
						Unit* nextUnit = unitIter->second;
						if (nextUnit != NULL)
						if (nextForceSide->uuid == nextUnit->forceSideUuid)
							nextUnit->hostilityCode = nextForceSide->HostilityCode;
					}// end for(unitIter...
				}// end for (ForceSideIter...
			}// end if(endTag == "C2SIMInitializationBody")

			if (endTag == "ForceSide") {
				parsingForceSide = false;
				if (thisForceSide != NULL) {
					if (thisForceSide->uuid == "") {
						displayError("ERROR - FORCESIDE IN C2SIMINITIALIZATION MISSING UUID");
						return;
					}
					forceSideMap[thisForceSide->uuid] = thisForceSide;
				}
			}

			if (endTag == "Entity") {
				parsingEntity = false;

				// end of a unit - map it
				if (thisUnit != NULL) {
					if (thisUnit->uuid == "") {
						displayError("ERROR - UNIT IN C2SIMINITIALIZATION MISSING UUID");
						return;
					}

					// these will print error and not 
					// add unit if it alrady exists
					addUnit(thisUnit);
					addUnitByName(thisUnit);
				}
			}

			if (endTag == "SystemEntityList") {
				parsingSystemEntityList = false;
			}
		}
		else if (parsingIbmlOrder) {
			if (endTag == "OrderPushIBML") {
				foundFinalTag = true;
				skipThisDocument = true;
			}
		} 
		else if (parsingC2simOrder) {
			if (endTag == "OrderBody") {
				foundFinalTag = true;
				skipThisDocument = true;
				if (thisOrderUuid == "") {
					displayError("ERROR - ORDER WITH TASK:" + thisTask->taskName +
						" MISSING ORDERID");
					return;
				}

				// insert this OrderID in its Tasks
				for (std::map<std::string, Task*>::iterator taskIt = taskMap.begin();
					taskIt != taskMap.end();
					taskIt++){
					Task* nextTask = taskIt->second;
					if (nextTask->orderUuid == "")
						nextTask->orderUuid = thisOrderUuid;
				}
			}
			if (endTag == "Task"){
				// save the sender & receiver for reporting
				Unit* performingUnit = unitMap[thisTask->taskeeUuid];
				if (performingUnit == NULL) {
					displayError("ERROR - TASK:" + thisTask->taskName +
						" PERFORMINGENTITY NOT INITIALIZED");
					skipThisDocument = true;
					delete thisTask;
					thisTask = NULL;
					tasksThisOrder = 0;
					foundTaskTag = false;
					return;
				}
				if (thisTask->taskName == "") {
					displayError("ERROR - TASK WITH UUID:" + thisTask->taskUuid +
						" MUST HAVE TASKNAME");
					skipThisDocument = true;
					delete thisTask;
					thisTask = NULL;
					tasksThisOrder = 0;
					foundTaskTag = false;
					return;
				}
				if (thisTask->taskName.find(' ') != std::string::npos) {
					displayError("ERROR - TASK NAME:" + thisTask->taskName +
						" CONTAINS A BLANK");
					skipThisDocument = true;
					delete thisTask;
					thisTask = NULL;
					tasksThisOrder = 0;
					foundTaskTag = false;
					return;
				}
				performingUnit->reportToReceiver = orderFromSender;
				performingUnit->reportFromSender = orderToReceiver;

				// enter task into taskMap
				if (!addTask(thisTask))
					skipThisDocument = true;
				foundTaskTag = false;
				thisTask = NULL;
			}
		}	
	}

	// delete latestTag
	latestTag = "";

}// end C2SIMxmlHandler::endElement


 // character data
 // TODO: per documentation, this could come in pieces; 
 // all pieces should be collected before acting on it
void C2SIMxmlHandler::characters(
	const XMLCh* const data,
	const XMLSize_t dataLength) {

	copyXMLChLessNs(dataText, data);
	if (skipThisDocument)return;

	// to see tags and data parsed uncomment next line
	//std::cout << "TAG:" << latestTag << "|DATA:" << dataText << "|\n";
	
	// if parse conditions not met just return
	if (!foundRootTag || foundFinalTag || latestTag.empty())return;
	
	// look for order element tags and copy their data one tag at a time

	// starting here we parse the various possible XML inputs
	// for our purposes C2SIM and IBML09 are semantically equivalent
	// so we store the results in a single set of task variables
	
	// C2SIM Order
	if (parsingC2simOrder) {

		// look for sender and receiver
		if (orderFromSender == "") {
			if (latestTag == "FromSender")
				orderFromSender = dataText;
		}
		if (orderToReceiver == "") {
			if (latestTag == "ToReceiver")
				orderToReceiver = dataText;
		}

		// look for OrderID
		if (thisOrderUuid == "") {
			if (latestTag == "OrderID")
				thisOrderUuid = dataText;
		}
		
		// don't start parsing Order before Task tag
		if (!foundTaskTag)return;
		
		// look for the TaskID
		if (thisTask->taskUuid == "") {
			if (latestTag == "UUID") {
				thisTask->taskUuid = dataText;
				return;
			}
		}

		// look for the task Name
		if (thisTask->taskName == "") {
			if (previousTag != "StartTime" && latestTag == "Name") {
				thisTask->taskName = dataText;
				return;
			}
		}

		// look for the PerformingEntity
		if (thisTask->taskeeUuid == "") {
			if (latestTag == "PerformingEntity") {
				thisTask->taskeeUuid = dataText;
				thisTask->performingEntity = dataText;
				return;
			}
		}

		// look for the AffectedEntity
		if (thisTask->affectedEntity == "") {
			if (latestTag == "AffectedEntity") {
				thisTask->affectedEntity = dataText;
				return;
			}
		}

		// look for poorly named TaskNameCode
		if (thisTask->actionTaskActivityCode == "") {
			if (latestTag == "TaskNameCode") {
				thisTask->actionTaskActivityCode = dataText;
				return;
			}
		}

		// look for DateTime
		if (thisTask->dateTime == "") {
			if (latestTag == "IsoDateTime") {
				thisTask->dateTime = dataText;
				return;
			}
		}

		// look for latitude of next point
		if (latestTag == "Latitude") {
			if (thisTask->latitudePointCount >= MAXPOINTS) {
				std::cerr << "too many Latitudes; deleted " << dataText << "\n";
				return;
			}
			thisTask->latitudes[thisTask->latitudePointCount++] = dataText;
			return;
		}

		// look for longitude of next point
		if (latestTag == "Longitude") {
			if (thisTask->longitudePointCount >= MAXPOINTS) {
				std::cerr << "too many Longitudes; deleted " << dataText << "\n";
				return;
			}
			thisTask->longitudes[thisTask->longitudePointCount++] = dataText;
			return;
		}

		// look for elevation of next point
		if (latestTag == "AltitudeAGL") {
			if (thisTask->elevationPointCount >= MAXPOINTS) {
				std::cerr << "too many Elevations; deleted " << dataText << "\n";
				return;
			}
			thisTask->elevations[thisTask->elevationPointCount++] = dataText;
			return;
		}

		// must be some tag we don't care about
		dataText = "";

		return;

	}// end parsingC2simOrder

	// IBML09 order
	else if (parsingIbmlOrder) {

		// don't start parsing Order before Task tag
		if (!foundTaskTag)return;
		if(thisTask == NULL)thisTask = makeNewTask();

		// look for the TaskId
		if (thisTask->taskUuid == "") {
			if (latestTag == "TaskID") {
				thisTask->taskUuid = dataText;
				thisTask->taskName = dataText;
				return;
			}
		}

		// look for the taskeeUuid 
		if (thisTask->taskeeUuid == "") {
			if (latestTag == "TaskeeWho") {
				thisTask->taskeeUuid = dataText;
				return;
			}
		}
		
		// look for actionTaskActivityCode
		if (thisTask->actionTaskActivityCode == "") {
			if (latestTag == "WhatCode") {
				thisTask->actionTaskActivityCode = dataText;
				return;
			}
		}

		// look for dateTime
		if (thisTask->dateTime == "") {
			if (latestTag == "DateTime") {
				thisTask->dateTime = dataText;
				return;
			}
		}

		// look for latitude of next point
		if (latestTag == "Latitude") {
			if (thisTask->latitudePointCount >= MAXPOINTS) {
				std::cerr << "too many latitudes; deleted starting at " << dataText << "\n";
				return;
			}
			thisTask->latitudes[thisTask->latitudePointCount++] = dataText;
			return;
		}

		// look for longitude of next point
		if (latestTag == "Longitude") {
			if (thisTask->longitudePointCount >= MAXPOINTS) {
				std::cerr << "too many longitudes; deleted " << dataText << "\n";
				return;
			}
			thisTask->longitudes[thisTask->longitudePointCount++] = dataText;
			return;
		}

		// look for elevation of next point
		if (latestTag == "ElevationAGL") {
			if (thisTask->elevationPointCount >= MAXPOINTS) {
				std::cerr << "too many longitudes; deleted " << dataText << "\n";
				return;
			}
			thisTask->elevations[thisTask->elevationPointCount++] = dataText;
			return;
		}

		// must be some tag we don't care about
		dataText = "";
		return;

	}// end else if (parsingIbmlOrder)

	// C2SIMInitialization message - only one instance per run
	else if (parsingC2simInitialize) {

		// ForceSide
		if (parsingForceSide) {

			// look for UUID
			if (thisForceSide->uuid == "") {
				if (latestTag == "UUID") {
					thisForceSide->uuid = dataText;
				}
			}

			// look for SideHostilityCode
			if (thisForceSide->HostilityCode == "") {
				if (latestTag == "SideHostilityCode") {
					thisForceSide->HostilityCode = dataText;
				}
			}
		}// if(parsingForceSide)

		// Entity and all of Unit data
		else if (parsingEntity) {

			// look for UUID
			if (thisUnit->uuid == "") {
				if (latestTag == "UUID") {
					thisUnit->uuid = dataText;
					return;
				}
			}

			// look for Name
			if (thisUnit->name == "") {
				if (latestTag == "Name") {
					thisUnit->name = dataText;
					return;
				}
			} 

			// look for Side (this is a ForceSide, needed for HostilityCode)
			if (thisUnit->forceSideUuid == "") {
				if (latestTag == "Side") {
					thisUnit->forceSideUuid = dataText;
					return;
				}
			}

			// look for OperationalStatusCode
			if (thisUnit->opStatusCode == "") {
				if (latestTag == "OperationalStatusCode") {
					thisUnit->opStatusCode = dataText;
					return;
				}
			}

			// look for StrengthPercentage
			if (thisUnit->strengthPercent == "") {
				if (latestTag == "StrengthPercentage") {
					thisUnit->strengthPercent = dataText;
					return;
				}
			}

			// look for echelon
			if (thisUnit->echelon == "") {
				if (latestTag == "Echelon") {
					thisUnit->echelon = dataText;
					return;
				}
			}

			// look for SuperiorUnit
			if (thisUnit->superiorUnit == "") {
				if (latestTag == "Superior") {
					thisUnit->superiorUnit = dataText;
					return;
				}
			}

			// look for Latitude
			if (thisUnit->latitude == "") {
				if (latestTag == "Latitude") {
					thisUnit->latitude = dataText;
					return;
				}
			}

			// look for Longitude
			if (thisUnit->longitude == "") {
				if (latestTag == "Longitude") {
					thisUnit->longitude = dataText;
					return;
				}
			}

			// look for ElevationAGL
			if (thisUnit->elevationAgl == "1000.") {
				if (latestTag == "ElevationAGL") {
					thisUnit->elevationAgl = dataText;
					return;
				}
			}

			// look for Euler angle Phi
			if (thisUnit->directionPhi == "") {
				if (latestTag == "Phi") {
					thisUnit->directionPhi = dataText;
					return;
				}
			}

			// look for Euler angle Psi
			if (thisUnit->directionPsi == "") {
				if (latestTag == "Psi") {
					thisUnit->directionPsi = dataText;
					return;
				}
			}

			// look for Euler angle Theta
			if (thisUnit->directionTheta == "") {
				if (latestTag == "Theta") {
					thisUnit->directionTheta = dataText;
					return;
				}
			}

			// look for SymbolIdentifier
			if (thisUnit->symbolId == "") {
				if (latestTag == "SIDCString") {
					thisUnit->symbolId = dataText;
					return;
				}
			}

			// look for DISEntityType
			if (thisUnit->disEntityType == "") {
				if (latestTag == "EntityTypeString") {
					thisUnit->disEntityType = dataText;
					return;
				}
			}
		}//end if(parsingEntity)

        // SystemEntityList
		else if(parsingSystemEntityList) {

			// look for ActorReference
			if (latestTag == "ActorReference"){
				actors.push_back(dataText);
				return;
			}

			// look for SystemName
			if (latestTag == "SystemName") {

				// copy the SystemName to all actor units
				for (auto &actor:actors) {
					Unit* unitToUpdate = unitMap[actor];
					if (unitToUpdate == NULL){
						displayError("ERROR IN SYSTEM ENTITY LIST- NO UNIT MATCHING ACTOR REFERENCE:"
							+ actor);
						skipThisDocument = true;
						rootTag = "";
					}
					else unitToUpdate->systemName = dataText;
				}
				return;
			}
		}// end else if (parsingSystemEntityList)

		// must be some tag we don't care about
		dataText = "";
		return;

	}// end else if(parsingC2simInitialization)
	
	// control message 
	else if (parsingSystemCommandTypeCode) {
		if (latestTag == "State") {
			systemState = dataText;
			return;
		}
		if (latestTag == "SystemCommandCode") {
			systemState = dataText;
		}
	}//end else if(parsingSystemCommandTypeCode)

}// end C2SIMxmlHandler::characters

void C2SIMxmlHandler::fatalError(const SAXParseException& exception)
{
	char* message = XMLString::transcode(exception.getMessage());
	std::cerr << "Fatal Error: " << message <<
		" at line: " << exception.getLineNumber() << 
		" column:" << exception.getColumnNumber() << "\n";
	XMLString::release(&message);
}
