Move the .exe file in this folder into c2simVRFinterfacev2.24\bin64

They will overwrite existing files

NOTE: The DIS version has not been tested; HLA version is believed to work properly with VRForces 5.0.1a running task-follows-task, no matter which order the Tasks are submitted in C2SIM Orders.