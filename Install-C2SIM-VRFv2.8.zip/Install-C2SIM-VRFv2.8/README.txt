INSTALLING C2SIMv9 INTERFACE AND ADDITIONS TO VRFORCESv4.7

Thanks for help from Doug Reece of MAK.

Note that this version requires Microsoft Visual Studio 2015 and requires VR-Link5.4.1 installed.

This folder contains interface program c2simVRF and also some configuration data for creating 
mobile forces: armored cavalry section, mobile infantry squad, mobile irregular team, a script 
for a Chinook to perform an evacuation mission, and another for generating reports input for C2SIM.

1. Copy the c2simVRFv2.8 directory to wherever you want it to run, for example C:\. It 
contains a batch file runc2simVRF.bat to run the program. You can make a Windows shortcut from
this file and place it on your desktop to start the interface. The parameters are defined in
program module main.cxx. The system name VRFORCES must match the SystemName in C2SIM initialzation.
The first parameter is the IP address of the C2SIM server; you should edit it to point to the 
server you are using.

2. Add to your Windows Path Environment Variable:
C:/MAK/vrforces4.7/bin64 and C:/MAK/vrlink5.4.1/bin64

3. Copy the appData, data, and userData folders from VRFadditionalFiles into the top level of 
VRForces 4.7 installation (e.g. c:\MAK\vrforces4.7). It will add/change files in 
appData\definitions, data\simulationModelSets\entityLevel\vrfSim, and 
data\simulationModelSets\entityLevel\scripts.

4. To use the aggregated friendly (Scout Platoon) or adversary (Mobile Irregular) from the VRForces 
GUI you would look for AR Scout on the entity creation menu. Or from the C2SIM Interface, you 
would call createAggregate instead of createEntity. See for example createScoutUnit in c2simVRFv2.8/C2SIMinterface.cpp.

5. The Tracking_Reports scripts cause VRForces to emit entity position information in textIf.cpp
which are used by the reportCallback function in c2simVrfv2.8/textIf.cpp to create reports.
However there is a bug in VR-Forces 4.7 that causes an error when these scripts are run, so a 
temporary workaround has been provided in c2simVRF that generates position reports without the 
scripts, and thus the scripts are not included in VRFadditionalFiles.

6. To use the scenario data loaded: in the VRForces GUI Scenario Startup panel select 
"read from disk" and click on Bogaland. You will have to wait while VRForces downloads the
terrain from Internet - when it arrives it should include a green playbox. When you shutdown 
VRForces do not choose to save as Bogaland scenario - that would replace it with whatever you 
have been running. If you want to save your latest scenario, give it a different name.

7. To run the c2simVRF interface, start VRForces4.7 and then click on runC2simVRF.bat. If the 
parameters there describe an initialized C2SIM server that is reachable from your network, the 
interface will perform a late-joiner C2SIM initialization, connect to VRForces, and load into
VRForces simulation objects from the initialization, matching the SystemName in the .bat file.




