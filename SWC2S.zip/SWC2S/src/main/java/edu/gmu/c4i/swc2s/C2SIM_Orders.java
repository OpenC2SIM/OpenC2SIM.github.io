/*----------------------------------------------------------------*
|    Copyright 2020 Networking and Simulation Laboratory          |
|     C4I Center, George Mason University, Fairfax, Virginia      |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for academic purposes is hereby  |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

package edu.gmu.c4i.swc2s;


/**
 *
 * @author Douglas Corner - George Mason University C4I-Cyber Center
 */
public class C2SIM_Orders extends Thread {

    // Logon Information
    String swUser = "admin";
    String swPW = "admin";
    String swHost = "";
    String c2simHost = "";
    String url = "https://" + swHost + ":10006/sw/rest";

    
    /*********************************/
    /* C2SIM_Orders - Constructor    */
    /*********************************/
    C2SIM_Orders(String c2simHost, String swHost, String swUser, String swPW) {
        this.c2simHost = c2simHost;
        this.swHost = swHost;
        this.swUser = swUser;
        this.swPW = swPW;

    }   // C2SIM_Orders Constructor

    
    /****************************************************/
    /* run - Thread to process orders from Sitaware     */
    /****************************************************/
    public void run() {
        System.out.println("C2SIM_Orders run called - NOT IMPLEMENTED");
    }
}   // class C2SIM_Orders
