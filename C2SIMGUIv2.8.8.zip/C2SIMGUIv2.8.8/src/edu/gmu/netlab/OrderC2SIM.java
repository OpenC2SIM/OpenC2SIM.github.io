/*----------------------------------------------------------------*
|   Copyright 2009-2019 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/
package edu.gmu.netlab;

/**
 *
 * @author mpullen
 */
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import com.jaxfront.core.schema.ValidationException;
import com.jaxfront.core.util.URLHelper;
import com.jaxfront.core.util.io.cache.XUICache;
import java.io.*;
import java.net.*;
import edu.gmu.c4i.c2simclientlib2.*;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.util.Properties;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;

import java.awt.Toolkit;
import java.awt.event.MouseEvent;

import javax.swing.*;
import javax.swing.border.Border;
import com.jaxfront.core.dom.DOMBuilder;
import com.jaxfront.core.dom.Document;
import com.jaxfront.core.help.HelpEvent;
import com.jaxfront.core.help.HelpListener;
import com.jaxfront.core.schema.ValidationException;
import com.jaxfront.core.ui.TypeVisualizerFactory;
import com.jaxfront.core.util.LicenseErrorException;
import com.jaxfront.core.util.URLHelper;
import com.jaxfront.core.util.io.BrowserControl;
import com.jaxfront.core.util.io.cache.XUICache;
import com.jaxfront.pdf.PDFGenerator;
import com.jaxfront.swing.ui.editor.EditorPanel;
import com.jaxfront.swing.ui.editor.ShowXMLDialog;

import java.net.MalformedURLException;

import edu.gmu.c4i.c2simclientlib2.*;
import java.util.*;
import java.net.*;

// DOM and XPATH
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import javax.xml.parsers.*;
import javax.xml.namespace.NamespaceContext;

import org.w3c.dom.*;

/**
 * OrderC2SIM  Methods

 These methods support the C2SIMGUI object
 * 
 * @author	Mohammad Ababneh, C4I Center, George Mason University
 * @since	11/28/2011
 */ 
public class OrderC2SIM {
    
    private String bmlDocumentType = "";
    C2SIMGUI bml = C2SIMGUI.bml;
        
    // constructor
    public OrderC2SIM() 
    {
        bml.orderDomainName = "C2SIM";
        bml.generalBMLFunction = "C2SIM";
    }
	
    /**
     * Create a new C2SIM Order (XML Document)
     * 
     * mababneh 11/28/2011 + mpullen 06/24/2019
     */
    void newOrderC2SIM() {
        bml.releaseXUICache();
        bml.root = "MessageBody";
        bml.bmlDocumentType = "C2SIM Order";
        bml.documentTypeLabel.setText(bmlDocumentType);
        bml.releaseXUICache();
        bml.xsdUrl = 
            URLHelper.getUserURL(bml.c2simOrderSchemaLocation);
        bml.xmlUrl = null;		//Empty XML
        bml.xuiUrl = 
            URLHelper.getUserURL(
                bml.xuiFolderLocation + "/TabStyleOrderC2SIM.xui");// XUI Style
                bml.initDom(
                    "default-context", 
                    bml.xsdUrl, 
                    bml.xmlUrl, 
                    bml.xuiUrl, 
                    bml.root);    
               
        // load the order into JAXFront panel
        try{
            bml.loadJaxFront(
                null,
                "C2SIM Order",
                bml.c2simOrderSchemaLocation,
                "C2SIM_Order");
        } catch(Exception e) {
            bml.printError("Exception in loadJaxFront for C2SIM Order file:"+e);
            e.printStackTrace();
            return;
        }
                    
    }// end newOrderC2SIM()

    /**
     * Open an existing C2SIM Order (XML Document) from file system
     * 
     * mababneh 11/28/2011 mpullen 03/27/18
     */
    void openOrderFSC2SIM(String subFolder, boolean showOnMap) {
        bml.releaseXUICache();
        bml.bmlDocumentType = "C2SIM Order";	
        bml.documentTypeLabel.setText(bml.bmlDocumentType);
        bml.xsdUrl = //Schema File XSD
        URLHelper.getUserURL(bml.c2simOrderSchemaLocation);	
        JFileChooser xmlFc = //XML file
            new JFileChooser(
                bml.guiFolderLocation + bml.delimiter + subFolder + bml.delimiter);	
        xmlFc.setDialogTitle("Enter the Order XML file name");
        xmlFc.showOpenDialog(bml);
        if(xmlFc.getSelectedFile() == null)return;
        bml.xmlUrl = 
            URLHelper.getUserURL(xmlFc.getSelectedFile().toURI().toString());
        bml.tmpUrl = 
            URLHelper.getUserURL(xmlFc.getSelectedFile().toURI().toString() + "(tmp)");
        bml.tmpFileString = xmlFc.getSelectedFile().toString() + "(tmp)";
        bml.xuiUrl = // Jaxfront XUI file
            URLHelper.getUserURL(bml.xuiFolderLocation + "/TabStyleOrderC2SIM.xui");
        bml.root = "MessageBody";
        
        // adjust for ASX order 
        bml.currentXmlString = bml.readAnXmlFile(xmlFc.getSelectedFile().getAbsolutePath());
        String schemaFileLocation = bml.c2simOrderSchemaLocation;
        String taskTag = "ManeuverWarfareTask";
        if(bml.currentXmlString.contains("Autonomous")){
            schemaFileLocation = bml.asxOrderSchemaLocation;// ASX order schema XSD
            taskTag = "AutonomousSystemManeuverWarfareTask";
        }
        bml.xsdUrl = URLHelper.getUserURL(schemaFileLocation);
        
        
        // load the order into JAXFront panel
        try{
            bml.loadJaxFront(
                xmlFc.getSelectedFile(),
                "C2SIM Order",
                schemaFileLocation,
                bml.root);
        } catch(Exception e) {
            bml.printError("Exception in C2SIM Order file:"+e);
            e.printStackTrace();
            return;
        }

        // Generate the swing GUI only if not
        // autodisplaying C2SIM orders
        if(showOnMap)
            bml.drawFromXML(
              "default-context", 
              bml.xsdUrl, 
              bml.xmlUrl, 
              bml.xuiUrl, 
              bml.root, 
              bml.bmlDocumentType,
              "ManeuverWarfareTask",
              (new String[]{
                "PerformingEntity",
                "StartTime",
                "Name"}),
              (new String[]{
                "Latitude",
                "Longitude"}),
              bml.c2simns,
              null
            );
    }// end openOrderFSC2SIM()
	
    /**
     * Push an C2SIM Order (XML Document)
     * 
     * mpullen 4/1//2018
     */
    void pushOrderC2SIM() {
        
        if(bml.checkOrderNotPushable())return;
        String pushResultString ="";    // String to hold the result of the execution of the SBML XML query
        String pushOrderInputString ="";// String to hold the input to the SBML XML query
        String conversationID = "";
     
        // open connection to REST server
        if(bml.submitterID.length() == 0) {
            bml.showInfoPopup( 
                "cannot push C2SIM Order - submitterID required", 
                "C2SIM Order Push Message");
            return;
        }
        BMLClientREST_Lib c2simClient = 
            new BMLClientREST_Lib(
                "BMLC2GUI@"+bml.localAddress,
                bml.serverName,
                "ORDER");
        c2simClient.setPort("8080");
        c2simClient.setHost(bml.serverName);
        bml.printDebug("C2SIM Order Host:"+bml.serverName);
        c2simClient.setSubmitter(bml.submitterID);
        bml.printDebug("C2SIM Order Submitter:"+bml.submitterID);
        c2simClient.setPath("BMLServer/bml");
        c2simClient.setDomain(bml.orderDomainName);
        c2simClient.setProtocol("C2SIM");
	
        // should push BML from memory but for now use a file
        FileReader xmlFile;
        bml.printDebug("In C2SIM Order XML file:"+bml.xmlUrl);
        try{
          xmlFile=new FileReader(new File(bml.xmlUrl.getFile()));
          int charBuf; 
          while((charBuf = xmlFile.read())>0) {
            pushOrderInputString += (char)charBuf;
          }
        }
        catch(Exception e) {
          bml.printError("Exception in reading XML file:"+e);
          e.printStackTrace();
          return;
        }
        bml.printDebug("PUSH C2SIM XML:"+pushOrderInputString);

        // set parameters and send C2SIM message
        conversationID = c2simClient.getC2SIMHeader().getConversationID();
        try{
            pushResultString = 
                c2simClient.bmlRequest(pushOrderInputString);
        } catch (BMLClientException bce) {
            bml.showInfoPopup( 
                "exception pushing C2SIM Order:" +
                    bce.getMessage()+" cause:" + bce.getCauseMessage(), 
                "C2SIM Order Push Message");
            bce.printStackTrace();
            return;
        }
        bml.showInfoPopup( 
            pushResultString , 
            "C2SIM Order Push Message");
        
        // clear the data
        bml.xmlUrl = null;
    
    }// end pushOrderC2SIM()
    
    /**
     * saves C2SIM order to a file location chosen by user
     */
    void saveJaxFrontOrderC2SIM() {
        try {
            bml.saveJaxFront();
        } catch(Exception e) {
            bml.printError("Exception in saving XML file:"+e);
            e.printStackTrace();
            return;
        }
    }// end saveOrderC2SIM()
    
}// end class OrderC2SIM
