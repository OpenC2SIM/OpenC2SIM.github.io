/*----------------------------------------------------------------*
|    Copyright 2022 Networking and Simulation Laboratory          |
|     C4I Center, George Mason University, Fairfax, Virginia      |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for academic purposes is hereby  |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/
package edu.gmu.c4i.swc2s;

import java.lang.Exception;
import edu.gmu.c4i.swclient.SW_RESTClient;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URI;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import javax.ws.rs.core.Response;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import java.lang.String;

/**
 *
 * @author Douglas Corner - George Mason University C4I-Cyber Center
 */
public class SWInterface {

    //  Instance variables
    String baseURL;
    String userID;
    String password;
    String host;
    URI uri;
    String layersPath = "/v1/layerCatalogue";
    String symbolsPath = "/v2/layers/$LAYER/symbols";
    String deletePath = "/v2/layers/$LAYER/symbols/$SYMBOL";
    String symbolsInLayerPath = "/v2/layers/$LAYER/symbols";

    SW_RESTClient client;

    /************************************************/
    /*  Constructor with URL, userID and password   */
    /************************************************/
    public SWInterface(String baseURL, String userID, String password) throws Exception {
        this.baseURL = baseURL;
        this.userID = userID;
        this.password = password;
        uri = new URI(baseURL);
        client = new SW_RESTClient(uri, userID, password);
    }   // SWInterface Constructor

    /********************************/
    /* Query against SW database    */
    /********************************/
    String swGET(String path) throws Exception {
        Document d = null;
        String jResult = "";
        String inputLine;
        JSONObject ja = null;
        String xml = null;
        SAXBuilder sb;
        try {

            // Do the get and read the response.
            Response resp = client.restGet(path);

            // Check success of call
            if (resp.getStatus() != 200) {
                throw new Exception("Bad Return - HTTP Status = " + resp.getStatus());
            }

            jResult = resp.readEntity(java.lang.String.class);

            // Close the connection
            resp.close();

        } // try 
        catch (Exception e) {
            System.out.println("Exception in SWInterface:get " + e);
            e.printStackTrace();
        }   // catch

        return jResult;

    }   // swGET()
    
    
    /********************/
    /*  getAllUnits   */
    /********************/
    JSONArray getAllUnits(String layerID) throws Exception {

        try {
            String path = "/v2/layers/" + layerID + "/symbols";
            String symbols = swGET(path);
            JSONArray ja = new JSONArray(symbols);
            return ja;
        } // try // try
        catch (Exception e) {
            throw new Exception("Exception caught in getAllSymbols " + e);
        }   // catch
    }   // getAllUnits

    
    /************************/
    /* getAllUnitsInLayer    */
    /************************/
    JSONArray getAllUnitsInLayer(String layerId) throws Exception {
        String path = "/v2/layers/" + layerId + "/symbols";
        String symbols = swGET(path);
        JSONArray ja = new JSONArray(symbols);
        return ja;
    }   // getAllUnitsInLayer

    
    /********************/
    /*  deleteUnit    */
    /********************/
    void deleteUnit(String layerID, String symbolID) throws Exception {
        try {
            String path = "/v2/layers/" + layerID + "/symbols/" + symbolID;
            Response r = client.restDelete(path);
            int stat = r.getStatus();
            if (stat > 299) {
                throw new Exception("Error return from HttpClient (" + stat + ")  in delteUnit");
            }
            r.close();
        } // try
        catch (Exception e) {
            throw new Exception("Exception caught in deleteUnit " + e);
        }   // catch    
    }   // deleteUnit

    
    /****************/
    /*  addUnit   */
    /****************/
    Response addUnit(JSONObject sym, String layerId) throws Exception {
        String path = "/v2/layers/" + layerId + "/symbols";
        Response r = client.restPost(path, sym.toString());
        if (r.getStatus() != 200) {
            throw new Exception("Error in addSymbol - " + r.getStatus() + " - " + r.getStatusInfo());
        }
        r.close();
        return r;

    }   // addUnit

    
    /********************/
    /* getAllLayers     */
    /********************/
    JSONObject getAllLayers() throws Exception {
        JSONObject o;
        try {
            // Get the Layer Catalogue as a JSON string
            String layers = swGET(layersPath);

            // Convert  to a JSON object
            o = new JSONObject(layers);
        } // try
        catch (Exception e) {
            throw new Exception("Exception thrown during getAllLayers: " + e);
        }
        return o;
    }   // getAllLayers
    

    /****************/
    /* getJsonItem      */
    /****************/
    // Get a particular JSON object from a array of objects (Often items[])
    JSONObject getJsonItem(JSONArray items, String key, String value) {

        // Search through the items looking for a particular object
        JSONObject jo;
        for (int i = 0; i < items.length(); ++i) {
            jo = items.getJSONObject(i);
            String target = jo.getString(key);
            if (jo.get(key).equals(value)) {
                return jo;
            }   // of
        }   // for
        return null;
    }   // getJsonItem()

    
    /******************/
    /*  getMapLayer   */
    /******************/
    JSONObject getMapLayer(String layerName) throws Exception {

        String id = null;
        String parentName = "";

        // Determine the parent layer for this layer
        switch (layerName) {
            case "GMU_Main":
                parentName = "GloballySignificant";
                break;

            case "GMU_Inactive":
                parentName = "GloballySignificant";
                break;

            case "SpotReports":
                parentName = "UncorrelatedEnemyAndUnknown";
                break;

            default:
                throw new Exception("Search for invalid layer name");
        }

        // Search down through the hierarchy of JSONArray's and JSONObject's
        try {
            // Get all layers
            JSONObject o = getAllLayers();

            // Get the "ownOrganizationC2Layers" object
            JSONObject oO = o.getJSONObject("ownOrganizationC2Layers");

            // items contains an array of objects.  Each object is a top layer which seem to correspont to MIP OIG's
            JSONArray ja = oO.getJSONArray("items");

            // Search through the list of items looking for upper layer
            for (int i = 0; i < ja.length(); ++i) {
                JSONObject jo = ja.getJSONObject(i);
                if (jo.getString("presentationName").equalsIgnoreCase(parentName)) {

                    // We have the upper layer.  Search its items for the target.
                    JSONArray ja2 = jo.getJSONArray("items");
                    for (int j = 0; j < ja2.length(); ++j) {
                        JSONObject jo2 = ja2.getJSONObject(j);
                        if (jo2.getString("presentationName").equalsIgnoreCase(layerName)) {
                            return jo2;
                        }
                    }   // for
                }   // if
            }   // for

        } // try
        catch (Exception e) {
            throw new Exception("Exception thrown during getMapLayer " + e);
        }
        return null;

    }   // getMapLayer()

    /****************/
    /* updateUnit */
    /****************/

    void updateUnit(JSONObject symbol, String layerId, String symbolId) throws Exception {
        String url = "v2/layers/" + layerId + "/symbols/" + symbolId;
        Response r = client.restPut(url, symbol.toString());
        if (r.getStatus() != 200) {
            throw new Exception("updateSymbol - return = " + r.getStatus() + "  " + r.getStatusInfo());
        }

        r.close();
    }   // updateUnit()

}   // class SWInterface
