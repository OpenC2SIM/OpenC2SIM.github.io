/*----------------------------------------------------------------*
|   Copyright 2009-2022 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 * package edu.gmu.c4i.sbmlsubscriber;
 */

package edu.gmu.netlab;

import com.jaxfront.core.util.URLHelper;
import java.io.File;
import javax.jms.*;
import java.util.*;
import java.util.HashMap;
import java.awt.Color;

// DOM and XPATH
import javax.xml.xpath.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Iterator;
import java.util.HashMap;
import javax.swing.*;
import javax.swing.JFileChooser;

import edu.gmu.c4i.c2simclientlib2.C2SIMClientSTOMP_Lib;
import edu.gmu.c4i.c2simclientlib2.C2SIMClientException;
import edu.gmu.c4i.c2simclientlib2.C2SIMSTOMPMessage;
import edu.gmu.c4i.c2simclientlib2.C2SIMHeader;

import org.w3c.dom.*;
import static edu.gmu.netlab.C2SIMdashboard.bml;
import static edu.gmu.netlab.DashboardEntry.MessageType;

/**
 * subscribes to STOMP server, reads STOMP message,
 * and if they are General Status Report posts them to map
 * 
 * @author dcorner
 * @author modified: mababneh
 * @since	3/1/2010
 * @param args the command line arguments
 */
public class Subscriber implements Runnable {
    
    static C2SIMdashboard bml = C2SIMdashboard.bml;
    public static String host = "HOSTNAME";
    static int count = 0;
    public static org.w3c.dom.Document listenerDocument;// the C2SIM document
    public static boolean subscriberIsOn = false;
    public static TopicConnection conn = null;
    public static TopicSession session = null;
    private String rcvDocumentType = "";
    
    String subDocReportType = "";
    String subDocUnitID = "";
    String subDocGDCLat ="";
    String subDocGDCLon ="";
    
    int messageCount = 0;
    
    HashMap<String,ArrayList<String>> validSystemMessage;
    
    /**
     * Constructor
     */
    public Subscriber() throws Exception {}
    
    /**
     * Method to stop Subscriber
     */
    public void stopSub() {
    	subscriberIsOn = false;
        if(!bml.getConnected())return;
        bml.setConnected(false);
        if(bml.debugMode)bml.printDebug(
            "Subscriber is OFF - No messages will be accepted");
        try {
            stomp.disconnect();
        } 
        catch (C2SIMClientException bce) {
            bml.printError(
                "C2SIM Client Exception in disconnect: " + bce.getMessage());
        } 
    }// end stopSub()
    
    /**
     * make a DOM Document from a String
     * @param is - input stream
     * @return
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException 
     */  
    public static org.w3c.dom.Document loadXmlFrom(java.io.InputStream is)
        throws org.xml.sax.SAXException, java.io.IOException
    {
        javax.xml.parsers.DocumentBuilderFactory factory =
            javax.xml.parsers.DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        javax.xml.parsers.DocumentBuilder builder = null;
        try
        {
            builder = factory.newDocumentBuilder();
        }
        catch (javax.xml.parsers.ParserConfigurationException ex) {}
        org.w3c.dom.Document doc = builder.parse(is);
        if(bml.debugMode)bml.printDebug("Document string" + doc.toString());
        is.close();
        return doc;
        
    }// end loadXmlFrom()
    
    /**
     *  Thread run() method to receive STOMP
     */
    C2SIMClientSTOMP_Lib stomp = null;
    String submitter;
    public void run() {
      
        // setup for subscription
        host = bml.serverName;
        if(bml.debugMode)bml.printDebug("Begin Subscriber");
        if(bml.debugMode)bml.printDebug("Subscribe to : " +  host);
        if(bml.debugMode)bml.printDebug("making STOMP connection");
        String user, domain, hostSource;
        Document doc;

        // Create STOMP Client Object
        stomp = new C2SIMClientSTOMP_Lib();

        // Set STOMP parameters
        user = "C2SIMcontrol";
        domain = "ServerMessageBody";
        hostSource = bml.serverName;
        stomp.setHost(hostSource);
        stomp.setDestination("/topic/C2SIM");
        
        // echo parameters to log
        System.out.println("Subscribing STOMP client parameters:" +
            "Domain:" + domain + " STOMP host:" + hostSource);

        // Connect to the host
        C2SIMSTOMPMessage response = null;
        if(!bml.getConnected()) {
            System.out.println("Connecting to STOMP server at " + 
                stomp.getHost());
            try {
                response = stomp.connect();
                if (response.getMessageBody()==null) {
                    bml.printError(
                        "Failed to connect to STOMP host: " + 
                        hostSource + " - " + response.getMessageBody());
                    subscriberIsOn = false;
                    bml.setConnected(false);
                    return;
                }
            }
            catch (C2SIMClientException bce) {
                bml.printError("exception in connect to STOMP:" + bce.getCauseMessage());
                bml.showErrorPopup(
                    "connect timed out - restart C2SIMcontrol to try again",
                    "Server connection failed");
            }
        } 
        if(response == null)return;
        System.out.println("STOMP connect response received");
        bml.setConnected(true);
        subscriberIsOn = true;
        
        // send server status request
        InitC2SIM initC2SIM = new InitC2SIM();
        initC2SIM.pushStatusC2SIM();
        initC2SIM.pushStatusPlayback();
        if(bml.runCoalitionControl.equals("1"))
            initC2SIM.pushStatusRecord();

        // Start listening
        C2SIMSTOMPMessage message = null;
        try{
            while (subscriberIsOn)
            {
                // read message with STOMP blocking until next
                try {
                    message = stomp.getNext_Block();
                } catch(NullPointerException npe) {
                    if(bml.debugMode)bml.printDebug("STOMP GETNEXTBLOCK NULLPOINTER");
                    npe.printStackTrace();
                    subscriberIsOn = false;
                    bml.setConnected(false);
                    return;
                }

                // network read error - display popup and stop reading
                if(message == null){
                    try{Thread.sleep(1);}catch(InterruptedException ie){}
                    continue;
                }

                // extract parameters from header
                try {
                    String selectorDomain = message.getHeader("selectorDomain");
                    String protocol = message.getHeader("protocol");
                    String protocolVersion = message.getHeader("c2sim-version");
                    submitter = message.getHeader("submitter");
                    String firstforwarder = message.getHeader("first-forwarder");
                    String messageSelector = message.getHeader("message-selector");
                    String messageBody = message.getMessageBody().trim();
                    if(bml.debugMode)
                        bml.printDebug(
                        "received STOMP protocol:" + protocol + 
                        " submitter:" + submitter +
                        " c2sim-version:" + protocolVersion +
                        " first-forwarder:" + firstforwarder +
                        " message-selector:" + messageSelector +
                        " messageBodyLength:" + messageBody.length());       
                    bml.threadSub.yield();
                    if(messageBody.length() == 0)continue;
                    interpretMessage(
                        messageBody, protocolVersion,messageSelector, submitter);
                } catch(NullPointerException npe) {
                    if(bml.debugMode)bml.printDebug("STOMP PARAMETERS NULLPOINTER");
                    npe.printStackTrace();
                    subscriberIsOn = false;
                    bml.setConnected(false);
                }
                
                // reset message and go back to wait loop
                message = null;
           
            }// end Subscriber while(subscriberIsOn)
        
        } catch(NullPointerException npe) {
          bml.printError("STOMP NULLPOINTER");
          npe.printStackTrace();
          subscriberIsOn = false;
          bml.setConnected(false);
        }
        catch(C2SIMClientException bce) {
            bml.printError("BMLClientException:" + bce.getMessage() +
                " cause:" + bce.getCauseMessage());
            bml.showErrorPopup( 
                "network read failed - disconnecting", 
                "Network Error Message");
            subscriberIsOn = false;
            bml.setConnected(false);
            bml.subscriberStatusLabel.setText("NO");
            bml.subscriberStatusLabel.setForeground(Color.RED);
        }
        catch(Exception e) {
          if(bml.debugMode)bml.printDebug("STOMP SUBSCRIBER EXCEPTION "+e.getMessage());
          e.printStackTrace();
          subscriberIsOn = false;
          bml.setConnected(false);
          bml.showInfoPopup("NETWORK DISCONNECT", "DISCONNECTED - RESTART CONTROL");
        } 
            
        // wait for messages to be delivered to the interpretMessage method
        while (subscriberIsOn) 
            try{Thread.sleep(100);}catch(InterruptedException ie){}
        
        // disconnect STOMP
        if(bml.getConnected()){
            try {
                stomp.disconnect();
            }
            catch(C2SIMClientException bce) {
                bml.printError("error disconnecting STOMP:" + bce.getCauseMessage());
            }
        }
        bml.setConnected(false);
        
    }// end run()
      
    /**
     * interprets MessageBody, saves data, and adds to map
     */
    public void interpretMessage(
        String messageBody, 
        String protocolVersion,
        String messageSelector,
        String submitter) {
        
        messageCount++;  

        // message could be server control, initialization, order or report
        // we care about only C2SIMMessage affecting server/recorder/player
        // note that we use the long name of new SISO C2SIM ontology here
        int index500 = messageBody.length();
        if(index500 > 500)index500 = 500;
        String first500 = messageBody.substring(0,index500);
        DashboardEntry dbe = new DashboardEntry();
        
        // for debugging, print the message
        //System.out.println("MESSAGEBODY PROTOCOL:" + protocolVersion + " SUBMITTER:" +
        //submitter + " SELECTOR:" + messageSelector + " FIRST500:\n" + messageBody);
       
        // confirm server has the protocol version we use
        if(!bml.c2simProtocolOK(protocolVersion) &&
           !protocolVersion.equals("1.0.2")){//debugx
            bml.printError("received wrong initialization protocol version:" + 
                protocolVersion);
            return;
        }        
        dbe.messageLength = messageBody.length();
        
        // parse DashboardEntry elements from the message
        if(messageBody.contains("<C2SIMInitializeBody") ||
            messageBody.contains("<ObjectInitialzationBody")) {
            dbe.messageType = MessageType.INITIALIZE;
            dbe.submitter = submitter;
        }
        else if(messageBody.contains("<SystemMessageBody>")) {
            dbe.messageType = MessageType.SYSTEM;
            
            // find the SystemMessage code
            int startCode = messageBody.indexOf("<SystemMessageBody")+20;
            int endCode = messageBody.indexOf(">",startCode);
            if(endCode < 20){
                bml.printError("malformed SystemMessage ignored");
                return;
            }
            int slashEndCode = messageBody.indexOf("/>",startCode)-1;
            if(slashEndCode > 1) 
                if(slashEndCode < endCode)endCode = slashEndCode;
            String systemCode = messageBody.substring(startCode,endCode);
            if(!bml.sysMessages.contains(systemCode)){
                bml.printError("unrecognized SystemMessage code:"+systemCode+"|");
                return;
            }
            dbe.systemMessageCode = systemCode;
        }
        else if (messageBody.contains("<SystemAcknowsystemCodeledgementBody")) {
            dbe.messageType = MessageType.ACKNOWLEDGE;
            dbe.ackType = parse(messageBody,"AcknowledgeTypeCode");
        }
        else if (messageBody.contains("<OrderBody")) {
            dbe.messageType = MessageType.ORDER;
            
            // parse Order and its first Task
            dbe.orderEntity = parse(messageBody,"Entity");
            dbe.issuedTime = parse(messageBody,"IssuedTime");
            dbe.orderID = parse(messageBody,"OrderID");
            dbe.issuedTime = parse(messageBody,"IssuedTime");
            dbe.requestingEntity = parse(messageBody,"RequestingEntity");
            dbe.firstTaskUUID = parse(messageBody, "TaskID");
            dbe.firstTaskAffected = parse(messageBody, "TaskAffectedEntity");
            dbe.firstTaskStartTime = parse(messageBody, "TaskID");
            dbe.firstTaskStartTime = parse(messageBody, "TaskStartTime");
            dbe.firstTaskAction = parse(messageBody, "TaskActionCode");
        }
        else if (messageBody.contains("<ReportBody")) {
            if(messageBody.contains("<ObservationReportContent")){
                dbe.messageType = MessageType.OBSERVATION_REPORT;
                
                // parse Observation Report
                dbe.reportingEntity = parse(messageBody, "<ReportingEntity");
                dbe.operationalStatusCode = parse(messageBody, "<OperationalStatusCodes");
                dbe.locationLat = parse(messageBody, "<Latitude");
                dbe.locationLon = parse(messageBody, "Longitude");
                dbe.reportDateTime = parse(messageBody, "<TimeOfObservation");
            }
            else if(messageBody.contains("<PositionReportContent>")){
            dbe.messageType = MessageType.POSITION_REPORT;
                
                // parse Position Report
                dbe.reportingEntity = parse(messageBody, "<ReportingEntity");
                dbe.operationalStatusCode = parse(messageBody, "<OperationalStatusCode");
                dbe.locationLat = parse(messageBody, "<Latitude");
                dbe.locationLon = parse(messageBody, "<Longitude");
                dbe.reportDateTime = parse(messageBody, "<IsoDateTime");
            }
        }
        else if(messageBody.contains("<TaskStatus")){
            dbe.messageType = MessageType.TASK_STATUS;
        } // end MessageBody else-if chain

        // make a string with all non-null values in message
        String summary = "source:" + submitter;
        // messageType
        if(dbe.messageType == null){
            bml.printError(
                "did not find messageTpe in message:" + messageBody);
            return;
        }
        switch (dbe.messageType) {
            case INITIALIZE:
                summary += "INITIALIZE";
                break;
            case SYSTEM: 
                summary += " SYSTEM";
                break;
            case ACKNOWLEDGE:
                summary += " ACKNOWLEDGE";
                break;                  
            case ORDER:
                summary += " ORDER";
                break;                                            
            case POSITION_REPORT:
                summary += " POSITION_REPORT";
                break;
            case OBSERVATION_REPORT:
                summary += " OBSERVATION_REPORT";
                break;
            case TASK_STATUS:
                summary += " TASK_STATUS";
                break;
            default:
        }
        // data elements
        if(dbe.submitter != null)summary += 
            (" submitter:" + dbe.submitter);
        if(dbe.systemMessageCode != null)summary += 
            (" systemMessageCode:"+dbe.systemMessageCode);
        if(dbe.ackType != null)summary += 
            (" ackType:"+dbe.ackType);
        if(dbe.orderEntity != null)summary += 
            (" orderEntity:"+dbe.orderEntity);
        if(dbe.issuedTime != null)summary += 
            (" issuedTime:"+dbe.issuedTime);
        if(dbe.orderID != null)summary += 
            (" orderID:"+dbe.orderID);
        if(dbe.requestingEntity != null)summary += 
            (" requestingEntity:"+dbe.requestingEntity);
        if(dbe.firstTaskUUID != null)summary += 
            (" firstTaskUUID:"+dbe.firstTaskUUID);
        if(dbe.firstTaskAffected != null)summary += 
            (" firstTaskAffected:"+dbe.firstTaskAffected);
        if(dbe.firstTaskStartTime != null)summary += 
            (" firstTaskStartTime:"+dbe.firstTaskStartTime);
        if(dbe.firstTaskAction != null)summary += 
            (" firstTaskAction:"+dbe.firstTaskAction);
        if(dbe.reportingEntity != null)summary += 
            (" reportingEntity:"+dbe.reportingEntity);
        if(dbe.operationalStatusCode != null)summary += 
            (" operationalStatusCode:"+dbe.operationalStatusCode);
        if(dbe.reportDateTime != null)summary += 
            (" reportDateTime:"+dbe.reportDateTime);
        if(dbe.locationLat != null)summary += 
            (" locationLat:"+dbe.locationLat);
        if(dbe.locationLon != null)summary += 
            (" locationLon:"+dbe.locationLon);
        summary += "\n\n";
        
        // add summary to the sender map woth key submitter
        // if there is an existing summary this will replace it
        bml.senderMap.put(submitter,summary);

        // reload textArea from latest senderMsp
        bml.textArea.selectAll();
        bml.textArea.replaceSelection("MOST RECENT TRAFFIC:\n\n");
        Collection<String> senderValues = bml.senderMap.values();
        Iterator iter = senderValues.iterator();
        while(iter.hasNext()){
            String dbeString = (String)iter.next();
            bml.textArea.append(dbeString);
        }
    } // end interpretMessage()
    
    // parse indicated element from an XML message
    String parse(String toSearch, String tag){
        String result = null;
        int start = toSearch.indexOf(tag)+tag.length()+1;
        if(start < 1)return result;
        int end = toSearch.indexOf("<",start);
        int slashEnd = toSearch.indexOf(" />",start);
        if(slashEnd < end && slashEnd > 2)end = slashEnd;
        if(end < 1)return result;
        result = toSearch.substring(start,end);
        return result;
    }// end parse()
    
    /**
     * Returns String YYYYMMDDHHMMSS.sss
     */
    public synchronized static String getTimeStamp() {
        Calendar now = Calendar.getInstance();        // Create a timestamp
        long i = System.currentTimeMillis() % 1000;
        String dttm = String.format("%04d/%02d/%02d %02d:%02d:%02d",
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH) + 1,
                now.get(Calendar.DATE),
                now.get(Calendar.HOUR_OF_DAY),
                now.get(Calendar.MINUTE),
                now.get(Calendar.SECOND),
                i);
        return dttm;
    }
    
} // end Subscriber Class
