/*----------------------------------------------------------------*
|   Copyright 2009-2019 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

package edu.gmu.netlab;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import com.jaxfront.core.schema.ValidationException;
import com.jaxfront.core.util.URLHelper;
import com.jaxfront.core.util.io.cache.XUICache;
import java.io.*;

/**
 * Order09  Methods

 These methods support the C2SIMGUI object
 * 
 * @author	Mohammad Ababneh, C4I Center, George Mason University
 * @since	11/28/2011
 */ 
public class Order09 {
    
    private String bmlDocumentType = "";
    C2SIMGUI bml = C2SIMGUI.bml;
    
    // constructor
    public Order09() 
    {
        bml.orderDomainName = "IBML";
        bml.generalBMLFunction = "IBML";
    }
	
    /**
     * Create a new IBML09 Order (XML Document)
     * 
     * mababneh 11/28/2011
     */
    void newOrder09() {
        bml.root = "OrderPushIBML";
        bmlDocumentType = "IBML09 Order";
        bml.documentTypeLabel.setText(bmlDocumentType);
        bml.releaseXUICache();

        // Order Schema IBML-MSG048-09/IBMLOrderPushPulls.xsd
        bml.xsdUrl = 
            URLHelper.getUserURL(bml.ibml09OrderSchemaLocation);
        bml.xmlUrl = null;		//Empty XML
        bml.xuiUrl = URLHelper.getUserURL(
            bml.xuiFolderLocation + "/TabStyleOrder09.xui");// XUI Style
        bml.initDom(
            "default-context", 
            bml.xsdUrl, 
            bml.xmlUrl, 
            bml.xuiUrl, 
            bml.root);

    }// end newOrder09()
	
    /**
     * Open an existing IBML09 Order (XML Document)
     * 
     * mababneh 11/28/2011
     */
    void openOrderFS09(String subFolder, boolean showOnMap) {
        bml.releaseXUICache();
        bml.bmlDocumentType = "IBML09 Order";	
        bml.documentTypeLabel.setText(bml.bmlDocumentType);
        bml.xsdUrl = //Schema File XSD
            URLHelper.getUserURL(bml.ibml09OrderSchemaLocation);	
        
        // chhose a file to open
        JFileChooser xmlFc = //XML file
            new JFileChooser(
                bml.guiFolderLocation + bml.delimiter + subFolder + bml.delimiter);	
        xmlFc.setDialogTitle("Enter the Order XML file name");
        xmlFc.showOpenDialog(bml);
        if(xmlFc.getSelectedFile() == null)return;
        
        bml.xmlUrl = 
            URLHelper.getUserURL(xmlFc.getSelectedFile().toURI().toString());
        bml.tmpUrl = 
            URLHelper.getUserURL(xmlFc.getSelectedFile().toURI().toString() + "(tmp)");
        bml.tmpFileString = xmlFc.getSelectedFile().toString() + "(tmp)";
        bml.xuiUrl = // Jaxfront XUI file
            URLHelper.getUserURL(bml.xuiFolderLocation + "/TabStyleOrder09.xui");
        bml.root = "OrderPushIBML";
                
        // load the order into JAXFront panel
        try{
            bml.loadJaxFront(
                xmlFc.getSelectedFile(),
                "IBML09 Order",
                bml.ibml09OrderSchemaLocation,
                bml.root);
        } catch(Exception e) {
            bml.printError("Exception loading JaxFront:"+e);
            e.printStackTrace();
            return;
        }
	
        // Generate the swing GUI only if not
        // autodisplaying IBML09 orders
        if(showOnMap)
        bml.drawFromXML(
            "default-context", 
            bml.xsdUrl, 
            bml.xmlUrl, 
            bml.xuiUrl, 
            bml.root, 
            bml.bmlDocumentType,
            "GroundTask",
            (new String[]{
                "UnitID",
                "DateTime",
                "WhereID",
                "WhereClass",
                "WhereCategory",
                "WhereLabel",
                "WhereQualifier"}),
            (new String[]{
              "Latitude",
              "Longitude"}),
            bml.ibmlns,
            null
        );
    }// end openOrderFS09()
	
    /**
     * Push an IBML09 Order (XML Document)
     * 
     * mababneh 11/28/2011
     */
    void pushOrder09() {
        
        if(bml.checkOrderNotPushable())return;
        String pushResultString ="";    // String to hold the result of the execution of the SBML XML query
        String pushOrderInputString ="";// String to hold the input to the SBML XML query
	
        // should push BML from file
        FileReader xmlFile;
        try{
          xmlFile=new FileReader(new File(bml.xmlUrl.getFile()));
          int charBuf; 
          while((charBuf = xmlFile.read())>0) {
            pushOrderInputString += (char)charBuf;
          }
        }
        catch(Exception e) {
          bml.printError("Exception in reading XML file:"+e);
          e.printStackTrace();
          return;
        }
        bml.printDebug("***PUSHXML:"+pushOrderInputString);

        // Running the SBML Query through the SBMLClient
        pushResultString = 
            bml.ws.processBML(
                pushOrderInputString, 
                bml.orderDomainName, 
                "BML", 
                "IBML Order Push");
        bml.showInfoPopup( 
            pushResultString , 
            "Order Push Message");
        
        // clear the data
        bml.xmlUrl = null;
    
    }// end pushOrder09()
    
}//end class Order09
