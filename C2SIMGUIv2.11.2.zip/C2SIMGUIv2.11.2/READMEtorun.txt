The BMLC2GUI can be run by invoking in this directory

for Linux and MacOSX, on command line: ./runGUI
(you may need to first run on command line "chmod +x ./runGUI")

for Microsoft Windows: runC2SIMGUI.bat

