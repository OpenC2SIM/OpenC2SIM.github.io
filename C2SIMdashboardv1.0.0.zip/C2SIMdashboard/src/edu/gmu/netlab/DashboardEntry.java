/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.netlab;

/**
 * collection of data for a Dashboard entry
 * pieces from all MessageBody types; where
 * not used they will be null
 * @author JMP
 */
public class DashboardEntry {
    
        public enum MessageType {
        INITIALIZE,
        SYSTEM,
        ACKNOWLEDGE,
        ORDER,
        POSITION_REPORT,
        OBSERVATION_REPORT,
        TASK_STATUS
    }
    public enum AckType {
        ACKFAIL,
        ACKNOTEXEC,
        ACKNOTRCGNA,
        ACKRCVD,
        ACKREQDEN,
        ACKRECGRT,
        ACKSUCC
    }
    int messageLength = 0;
    MessageType messageType = null;
    String submitter = null;
    String systemMessageCode = null;
    String ackType = null;
    String orderEntity = null;
    String issuedTime = null;
    String orderID = null;
    String requestingEntity = null;
    String firstTaskUUID = null;
    String firstTaskAffected = null;
    String firstTaskStartTime = null;
    String firstTaskAction = null;
    String reportingEntity = null;
    String operationalStatusCode = null;
    String reportDateTime = null;
    String locationLat = null;
    String locationLon = null;
    String summary = null;
        
}// end class DashboardEntry
