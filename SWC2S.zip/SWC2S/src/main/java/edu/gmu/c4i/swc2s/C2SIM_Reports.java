/*----------------------------------------------------------------*
|    Copyright 2020 Networking and Simulation Laboratory          |
|     C4I Center, George Mason University, Fairfax, Virginia      |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for academic purposes is hereby  |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/
package edu.gmu.c4i.swc2s;

import edu.gmu.c4i.c2simclientlib2.*;
import edu.gmu.c4i.c2simclientlib2.C2SIMSTOMPMessage;
import edu.gmu.c4i.c2simclientlib2.C2SIMClientREST_Lib;
import static edu.gmu.c4i.swc2s.SWC2S_Main.sw;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.input.SAXBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Douglas Corner - George Mason University C4I-Cyber Center
 */
public class C2SIM_Reports extends Thread {

    static Namespace c2simNS = Namespace.getNamespace("http://www.sisostds.org/schemas/C2SIM/1.1");
    static String swSymbol;
    C2SIMClientSTOMP_Lib c2s;
    
    // Logon Information
    String swUser = "admin";
    String swPW = "admin";
    String swHost = "10.46.254.100";
    String c2simHost = "";

    String url = "https://" + swHost + ":10006/sw/rest";
    static String gmu_main_layerID = "";

    // Constructor
    C2SIM_Reports(String c2simHost, String swHost, String swUser, String swPW) throws Exception {
        this.c2simHost = c2simHost;
        this.swHost = swHost;
        this.swUser = swUser;
        this.swPW = swPW;

        // Create SWinterface object and connect with user ID and password
        System.out.println("Connecting to Sitaware Server");
        sw = new SWInterface(url, swUser, swPW);
        System.out.println("Connection to Sitaware - Success");
        
        // Erase all symbols on the SW map
        clearMap();

        // Get the outline for a SW symbol.  Use as a template for new Unit Symbols
        swSymbol = C2SIM_Util.readFile("SWsymbol.json");

        // Open connection with C2SIM Server and subscribe to C2SIM traffic
        System.out.println("Connecting to STOMP server at " + c2simHost);
        c2s = new C2SIMClientSTOMP_Lib();
        c2s.setHost(c2simHost);
        c2s.setDestination("/topic/C2SIM");
        // 
        c2s.addAdvSubscription("message-selector = 'C2SIM_Report' or message-selector = 'C2SIM_Initialization'");
        C2SIMSTOMPMessage resp = c2s.connect();
        System.out.println(resp.getMessageType());

    }   // C2SIM_Reports Constructor

    // Report Processing Thread
    public void run() {

        Document doc;
        SAXBuilder sb = null;
        Document d = null;
        try {

            // Check status of server            
            System.out.println("Check status of C2SIM server at " + SWC2S_Main.c2simHost);

            C2SIMClientREST_Lib c2simRest = new C2SIMClientREST_Lib();
            c2simRest.setHost(c2simHost);
            c2simRest.setPath("Command");
            c2simRest.setSubmitter("SWC2S");
            String stat = c2simRest.c2simCommand("STATUS", "", "");

            // See if server is "RUNNING"
            if (stat.contains("<sessionState>RUNNING")) {
                System.out.println("C2SIM Server is UP");

                c2simRest.setPath("Command");
                System.out.println("Getting Initialization Data via QUERYINIT");
                String init = c2simRest.c2simCommand("QUERYINIT", "", "");
                String init2 = C2SIMHeader.removeC2SIM(init);
                processC2SIM_Init(init2);
            } else {
                System.out.println("C2SIM Server is NOT RUNNING");
            }

            // Process incoming messages
            while (true) {
                // Get next message from C2SIM Server
                C2SIMSTOMPMessage msg = c2s.getNext_Block();
                
                // Check the message-selector to determine what kind of message this is
                String msgSelector = msg.getHeader("message-selector");

                // Initialization ?
                if (msgSelector.equalsIgnoreCase("C2SIM_Initialization")) {
                    System.out.println("\nReceived: C2SIM_Initialization");

                    // Process the Initialization message
                    processC2SIM_Init(msg.getMessageBody());
                    
                } // C2SIM Initialization
                
                // Report ?
                else if (msgSelector.equalsIgnoreCase("C2SIM_Report")) {

                    // Process the report
                    processReport(msg.getMessageBody());
                    
                } // C2SIM_PotitionReport
                else {
                    System.out.println("Neither C2SIM_Initialization nor C2SIM_Report.  MSG Selector = " + msgSelector);
                    continue;
                }   // else
            }   // while true
        } // try 
        catch (Exception e) {
            System.out.println("Exception in C2SIM_Messages " + e);
        }   // catch

    }   // process

    /**************************/
    /* processReport          */
    /**************************/
    static void processReport(String message) throws Exception {
        Document c2simReportDoc = C2SIM_Util.parseMessage(message);
        Element reportRoot = c2simReportDoc.getRootElement();
        
        // Get list of reports 
        List<Element> c2simReportContents = C2SIM_Util.findElementSimple("DomainMessageBody/ReportBody/ReportContent", reportRoot, c2simNS);
        if (c2simReportContents.isEmpty()) {
            return;
        }

        // Process each report
        for (Element c2simReport : c2simReportContents) {
            
            // Is it a posisiton report?
            Element posReport = c2simReport.getChild("PositionReportContent", c2simNS);
            if (posReport == null) {
                continue;
            }
            // It is a position report - Process it
            processPosReport(posReport);

        }   // ReportContents

    }   // processReport        

    /*********************************/
    /* processC2SIM_Init  */
    /*********************************/
    static void processC2SIM_Init(String initMessage) throws Exception {

        System.out.println("Processing Initialization Message");
        
        // Parse message creating a JDOM Document
        Document c2simInitialization = C2SIM_Util.parseMessage(initMessage);

        // Get the root and list of Units
        Element root = c2simInitialization.getRootElement();

        // Get list of ObjectDefinitions
        List<Element> objectDefinitions = C2SIM_Util.findElementSimple("C2SIMInitializationBody/ObjectDefinitions", root, c2simNS);
        for (Element objectDefinition : objectDefinitions) {

            // Get list of entities
            List<Element> entities = C2SIM_Util.findElementSimple("Entity", objectDefinition, c2simNS);

            // Iterate through the list entities
            for (Element entity : entities) {
                // Get the militaryOrganization
                Element militaryOrganization = C2SIM_Util.findSingleElementSimple("ActorEntity/CollectiveEntity/MilitaryOrganization", entity, c2simNS);
                // If this entity is not a MilitaryOrganization, skip it
                if (militaryOrganization == null) {
                    continue;
                }

                // Create a symbol object
                JSONObject sym = processInitUnit(militaryOrganization);
                if (sym == null) {
                    continue;       // Something wrong with intialization data
                }
                // Add symbol to map

                String unitName = sym.getJSONObject("properties").getJSONObject("c2Attributes").getString("name");
                System.out.println("Calling SW2C2SIM_Main.addSymbol to add " + unitName);
                SWC2S_Main.sw.addUnit(sym, gmu_main_layerID);

            }   // for Entities
        }   // for ObjectDefinitions

    }   // processInitialization()

    /********************/
    /*  clearMap        */
    /********************/
    static void clearMap() throws Exception {
        // Reinitialize the MAP

        // Delete symbols in layers GMU_Main
        gmu_main_layerID = deleteAllUnits("GMU_Main");

        // Clear table that maps unit name to stored symbol
        SWC2S_Main.nameToSymbol = new HashMap<String, JSONObject>();

        // Clear HashMap that msps unit name to UUID
        SWC2S_Main.nameToUUID = new HashMap<String, String>();

        // Clear table that maps UUID to name
        HashMap<String, String> id2N = new HashMap<String, String>();

    }   // clearMap()

    /*************************/
    /*  processInitUnit      */
    /*************************/
    static JSONObject processInitUnit(Element militaryOrganization) throws Exception {

        String id;
        String name;
        String symbolCodeStr;
        String opstatus = "";
        String latitude = "";
        String longitude = "";
        JSONObject sym = null;

        try {
            // id and name
            id = militaryOrganization.getChildText("UUID", c2simNS);
            name = militaryOrganization.getChildText("Name", c2simNS);
            if (id == null) {
                System.out.println("ID is required for Unit Initialization.  Name = " + name);
                return null;
            }
            if (name == null) {
                System.out.println("Name is required for Unit Initialization.  UUID = " + id);
                return null;
            }

            if ((id == "") || (name == "")) {
                System.out.println("Both Name and ID are required in Unit Initialization " + " Name = " + name + " ID+ " + id);
                return null;
            }

            // Symbol Code
            Element entityType;
            List<Element> entityTypes = militaryOrganization.getChildren("EntityType", c2simNS);

            if (entityTypes.isEmpty()) {
                System.out.println("Entity type not provided for UUID " + id);
                return null;
            }

            entityType = entityTypes.get(0);
            Element symbolCode = C2SIM_Util.findSingleElementSimple("APP6-SIDC/SIDCString", entityType, c2simNS);
            if (symbolCode == null) {
                System.out.println("No SIDC string for UUID " + id);
                return null;       // No symbol code - Something wrong
            }
            symbolCodeStr = symbolCode.getText();

            // Operational Status
            List<Element> EHStatuss = C2SIM_Util.findElementSimple("CurrentState/PhysicalState/EntityHealthStatus", militaryOrganization, c2simNS);
            Element c2sim_OpStatus = null;
            for (Element EHStatus : EHStatuss) {
                c2sim_OpStatus = EHStatus.getChild("OperationalStatus", c2simNS);
                if (c2sim_OpStatus != null) {
                    Element opStatusCode = c2sim_OpStatus.getChild("OperationalStatusCode", c2simNS);
                    opstatus = translateOpStatus(opStatusCode.getText());    // Translate C2SIM to SW
                }
            }
            // Did we find an OpStatus?
            if (c2sim_OpStatus == null) {
                System.out.println("No Operational Status for UUID " + id);
                return null;
            }

            // Position
            Element c2sim_Coordinate = null;

            List<Element> c2sim_Locations = C2SIM_Util.findElementSimple("CurrentState/PhysicalState/Location", militaryOrganization, c2simNS);
            for (Element location : c2sim_Locations) {

                c2sim_Coordinate = location.getChild("GeodeticCoordinate", c2simNS);
                if (c2sim_Coordinate == null) {// No location something wrong
                    System.out.println("No location for UUID " + id);
                    return null;
                }

                Element c2sim_Latitude = c2sim_Coordinate.getChild("Latitude", c2simNS);
                if (c2sim_Latitude == null) {
                    System.out.println("No Latitude for UUID " + id);
                    return null;
                }
                latitude = c2sim_Latitude.getText();

                Element c2sim_Longitude = c2sim_Coordinate.getChild("Longitude", c2simNS);
                if (c2sim_Longitude == null) {
                    System.out.println("No Longitude for UUID" + id);
                    return null;
                }
                longitude = c2sim_Longitude.getText();
            }
            // Create a SW symbol object
            sym = unitToSymbol(id, name, symbolCodeStr, opstatus, latitude, longitude);
            if (sym == null) {
                return null;
            }

            // Save the symbol object for updating by position reports
            SWC2S_Main.nameToSymbol.put(name, sym);

            // Add to name to UUID map and UUID to name 
            SWC2S_Main.nameToUUID.put(name, id);
            SWC2S_Main.uuidToName.put(id, name);

        } catch (Exception e) {
            System.out.println("Exception in processInitialization " + e);
            System.out.println(e.getStackTrace());
        }
        return sym;
    }   // processInitialization()

    /*********************/
    /*  unitToSymbol   */
    /*********************/
    static JSONObject unitToSymbol(String id, String name, String symId, String opStatus,
            String latitude, String longitude) throws Exception {

        JSONObject sym = null;
        try {
            // Do we already have this unit?  If so skip it
            if (SWC2S_Main.nameToSymbol.containsKey(name)) {
                System.out.println("Duplicate Unit - Name = " + name + "  UUID = " + id);
                return null;
            }
            // Create new symbol from the outline stored on disk"
            sym = new JSONObject(swSymbol);

            // ID
            sym.put("id", "9:" + id);

            // Layer ID
            sym.put("layerId", gmu_main_layerID);

            // Move to properties
            JSONObject prop = sym.getJSONObject("properties");

            // properties reportTime
            Long tm = new Long(System.currentTimeMillis() / 1000);
            String tms = tm.toString();
            prop.put("reportTime", tms);

            // properties symbolCode
            prop.put("symbolCode", symId);

            // Move to properties.C2Attributes
            JSONObject c2Attr = prop.getJSONObject("c2Attributes");

            // Name
            c2Attr.put("name", name);

            // operationalStatus  -  Need documentation on this code
            c2Attr.put("operationalStatus", opStatus);

            // Move to properties.geometry
            JSONObject geo = prop.getJSONObject("geometry");

            // Coordinates
            JSONArray coords = new JSONArray();
            coords.put(longitude);
            coords.put(latitude);
            geo.put("coordinates", coords);

        } // try
        catch (Exception e) {
            System.out.println("Error in mapUnitToSymbol");
            System.out.println(e.getStackTrace());
        }
        return sym;
    }

    /************************/
    /*  processPosReport    */
    /************************/
    // Extract elements from C2SIM Position Report
    static JSONObject processPosReport(Element posReport) throws Exception {

        String name;
        String id;
        String reptTime;
        String latitude;
        String longitude;
        String opStatus;

        // id and name
        Element idE = posReport.getChild("SubjectEntity", c2simNS);
        if (idE == null) {
            return null;
        }

        // ID
        id = idE.getText();

        // Map id to name from Initialization
        name = SWC2S_Main.uuidToName.get(id);
        System.out.println("Received: PositionReport from " + id + " " + name);

        // ReportingTime
        Date rt = null;
        Long rtL = 0L;

        // Convert date/time to Long unix type date/time which is used by SitaWare
        //  If date is not present use current date/time
        Element inReptTime = posReport.getChild("TimeOfObservation", c2simNS);
        if (inReptTime != null) {
            Element isoT = C2SIM_Util.findSingleElementSimple("DateTime/IsoDateTime", inReptTime, c2simNS);
            if (isoT != null) {
                rt = SWC2S_Main.sdf.parse(isoT.getText());
            }
        } else // TimeOfObservation not in report 
        {
            rt = new Date();
        }

        rtL = rt.getTime();
        reptTime = rtL.toString();

        // Location - Lat Long
        Element geodetic = C2SIM_Util.findSingleElementSimple("Location/GeodeticCoordinate", posReport, c2simNS);
        if (geodetic == null) {
            return null;
        }

        Element latitudeE = geodetic.getChild("Latitude", c2simNS);
        if (latitudeE == null) {
            return null;
        }
        latitude = latitudeE.getText();

        Element longitudeE = geodetic.getChild("Longitude", c2simNS);
        if (longitudeE == null) {
            return null;
        }
        longitude = longitudeE.getText();

        // Health Status
        String c2simOpStatus = "";
        List<Element> statuses = C2SIM_Util.findElementSimple("EntityHealthStatus", posReport, c2simNS);
        for (Element status : statuses) {
            Element c2simOpStatusCode = C2SIM_Util.findSingleElementSimple("OperationalStatus/OperationalStatusCode", status, c2simNS);
            if (c2simOpStatusCode == null) {
                continue;
            }

            if (c2simOpStatusCode == null) {
                c2simOpStatus = "FullyOperational";
            } else {
                c2simOpStatus = c2simOpStatusCode.getText();
            }
        }   // for

        opStatus = translateOpStatus(c2simOpStatus);

        JSONObject symbol = updateUnit(name, id, reptTime, latitude, longitude, opStatus);

        return symbol;
    }

    /********************/
    /*  updateUnit      */
    /********************/
    // Update existing symbol with new position 
    static JSONObject updateUnit(String name, String id, String reportTime, String latitude, String longitude, String swOpStatus) throws Exception {

        JSONObject symbol = null;

        // Did we get this symbol during initialization?  
        //  If not did we get it from an earlier Positon Report?
        //  If not return null
        if (SWC2S_Main.nameToSymbol.containsKey(name)) {
            symbol = SWC2S_Main.nameToSymbol.get(name);
        } else {
            System.out.println("Report received for uninitialized Unit UUID = " + id + " Name = " + name);
            return null;
        }

        // Layer ID
        //symbol.put("layerId", gmu_inactive_layerID);
        // Update symbol (Either an existing one or one we just created) from report 
        JSONObject props = symbol.getJSONObject("properties");

        // Report time from the Position Report
        props.put("reportTime", reportTime);

        // Operational Status
        JSONObject c2Attr = props.getJSONObject("c2Attributes");
        c2Attr.put("operationalStatus", swOpStatus);

        // Position - Lat/Lon
        JSONObject geo = props.getJSONObject("geometry");
        JSONArray coords = new JSONArray();
        coords.put(longitude);
        coords.put(latitude);

        geo.put("coordinates", coords);

        // Update the symbol on the map
        String symbolId = symbol.getString("id");
        String layerId = symbol.getString("layerId");
        sw.updateUnit(symbol, layerId, symbolId);

        return symbol;

    }   // mapPOsReptToSymbol

    /************************/
    /*  translateOpStatus   */
    /************************/
// Translate C2SIM Opstatus to SitaWare OpStatus
    static String translateOpStatus(String c2simOpStatus) {

        String swOpStatus = "";
        // Map OperationalStatusCode to SW operationalStatus
        switch (c2simOpStatus) {
            case "NKN":
                swOpStatus = "0";
                break;
            case "FullyOperational":
                swOpStatus = "1";
                break;
            case "MOPS":
                swOpStatus = "2";
                break;
            case "NOP":
                swOpStatus = "3";
                break;
            case "SOPS":
                swOpStatus = "4";
                break;
            case "TOPS":
                swOpStatus = "5";
                break;
            default:
                System.out.println("Invalid OperationalStatusCode");
                swOpStatus = "0";
        }   // switch        
        return swOpStatus;
    }   // translateOpStatus()

    /**********************/
    /* deleteAllUnits()   */
    /**********************/
    static String deleteAllUnits(String layerName) throws Exception {
        // get the layer
        JSONObject jo = sw.getMapLayer(layerName);

        // Save the id
        String layerID = jo.getString("id");

        // Get the array of symbols
        JSONArray symbols = sw.getAllUnits(layerID);

        System.out.println("Deleting " + symbols.length() + " symbols  from " + layerName);
        // Delete the symbols, one at a time
        for (int i = 0; i < symbols.length(); ++i) {

            // Get a symbol its id and its name
            JSONObject symbol = symbols.getJSONObject(i);
            String symbolID = symbol.getString("id");
            String name = symbol.getJSONObject("properties").getJSONObject("c2Attributes").getString("name");

            // Delete the symbol
            System.out.println("Calling sw.deleteSymbol - " + name);
            sw.deleteUnit(layerID, symbolID);

        }   // for

        // Return the layerID
        return layerID;
    }   // deleteAllUnits(

}   // C2SIM_Reports   Class
