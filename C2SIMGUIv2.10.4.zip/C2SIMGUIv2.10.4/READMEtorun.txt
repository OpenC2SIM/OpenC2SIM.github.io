The BMLC2GUI can be run by invoking in this directory

for Linux and MacOSX: ./runBMLC2GUI

for Microsoft Windows: runBMLC2GUI.bat

