/*----------------------------------------------------------------*
|   Copyright 2009-2019 Networking and Simulation Laboratory      |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/
package edu.gmu.netlab;

import static edu.gmu.netlab.Subscriber.bml;
import java.util.HashMap;

/**
 * parses C2SIMInitializationBody and saves results in this class
 * @author mpullen
 */
public class MilOrg {
    
    static C2SIMGUI bml = C2SIMGUI.bml;
    
    // MessageBody
    // (public, to avoid need for getters)
    //String id;
    String uuid;
    String name;
    //String healthStatus;
    //String operationalStatusCode = "";
    //String strengthPercentage;
    String hostilityCode;
    //String echelon;
    //String superiorUnit;
    String latitude;
    String longitude;
    //String elevationAGL;
    String symbolIdentifier;
    //String forceSide;
    
    // constructor
    public MilOrg(){};
    
    // set/reset data values - must be called
    // forst time immediately after class instantiation
    void setValues(
        //String idValue,
        String uuidValue,
        String nameValue,
        //String healthStatusValue,
        //String operationalStatusCodeValue,
        //String strengthPercentageValue,
        String hostilityCodeValue,
        //String echelonValue,
        //String superiorUnitValue,
        String latitudeValue,
        String longitudeValue,
        //String elevationAGLValue,
        String symbolIdentifierValue
        //String forceSideValue
        )
    {
        uuid = uuidValue;
        //id = idValue;
        name = nameValue;
        //healthStatus = healthStatusValue;
        //operationalStatusCode = operationalStatusCodeValue;
        //strengthPercentage = strengthPercentageValue;
        hostilityCode = hostilityCodeValue;
        //echelon = echelonValue;
        //superiorUnit = superiorUnitValue;
        latitude = latitudeValue;
        longitude = longitudeValue;
        //elevationAGL = elevationAGLValue;
        symbolIdentifier = symbolIdentifierValue;
        //forceSide = forceSideValue;
    }// end setValues()
    
    void setUuid(String uuidRef){
        uuid = uuidRef;
    }
 
    void setName(String nameRef){
        name = nameRef;
    }
    
    void setLatitude(String latitudeRef){
        latitude = latitudeRef;
    }
    
    void setLongitude(String longitudeRef){
        longitude = longitudeRef;
    }
    
    void setSymbolIdentifier(String symbolIdRef){
        symbolIdentifier = symbolIdRef;
    }
    
    void setHostility(String hostilityCodeRef){
        hostilityCode = hostilityCodeRef;
    }
    
    String getName(){
        return name;
    }
    
    String getLatitude(){
        return latitude;
    }
    
    String getLongitude(){
        return longitude;
    }
    
    String getSymbolIdentifier(){
        return symbolIdentifier;
    }
    
    String getHostility(){
        return hostilityCode;
    }
    
    // parse a C2SIMInitializationBody - count the entities and
    // extract for each its Name, UUID and SymbolID, Lat and Lon
    // returns entityCount in the message
    int parseC2SIMInit(String messageBody) {
 
        // read the C2SIMInitializationBody and save it
        // for use in mapping the unit
        int entityCount = 0;
        MilOrg milOrg;
        String uuid = "";

        // pull out the friendly and hostile sides 
        // scan through all AbstractObjects
        HashMap<String,String> hostilityMap = new HashMap<>();
        String parseMessage = messageBody;
        int startAbstract = parseMessage.indexOf("<AbstractObject>")+15;
        while(startAbstract >= 15) {

            // strip off message to next AbstractObject tag
            parseMessage = parseMessage.substring(startAbstract);
            int endAbstract = parseMessage.indexOf("</AbstractObject>");

            // find the ForceSide for the AbstractObject
            int startForceSide =
                parseMessage.indexOf("<ForceSide>");
            if(startForceSide >= 0 && startForceSide < endAbstract) {

                // find the SideHostilityCode for this AbstractObject
                int startHostility = 
                    parseMessage.indexOf("<SideHostilityCode>")+19;
                if(startHostility >= 19 && startHostility < endAbstract) {
                    int endHostility =
                        parseMessage.indexOf("</SideHostilityCode>", startHostility);

                    // if the code exists, save {UUID,SideHostilityCode} pair in hashmap
                    if(endHostility >= 0 && endHostility < endAbstract) {
                        String hostility = parseMessage.substring(startHostility, endHostility);

                        // find the UUID
                        int startUuid =
                            parseMessage.indexOf("<UUID>")+6;
                        if(startUuid >= 6 && startUuid < endAbstract) {
                            int endUuid =
                                parseMessage.indexOf("</UUID>");    
                            if(endUuid >= 0 && endUuid < endAbstract) {
                                uuid = parseMessage.substring(startUuid, endUuid);
                                hostilityMap.put(uuid, hostility);
                            }
                        }// end insert {UUID,hostility}
                    }// end find UUID
                }// end find hostility
            }// end find ForceSide
            startAbstract = parseMessage.indexOf("<AbstractObject>")+15;
        }

        // parse out the MilOrg data we want
        parseMessage = messageBody;
        int startEntity = parseMessage.indexOf("<Entity>")+8;
        while(startEntity > 8) {

            // strip off message text up to next Entity tag
            parseMessage = parseMessage.substring(startEntity);
            int endEntity = parseMessage.indexOf("</Entity>");
            milOrg = new MilOrg();
            int startData, endData;

            // collect MilOrg data

            // UUID
            startData = parseMessage.indexOf("<UUID>")+6;
            endData = parseMessage.indexOf("</UUID>",startData);
            if(endData >= 0 && endData < endEntity)uuid = 
                parseMessage.substring(startData, endData);
            milOrg.setUuid(uuid);

            // Name
            String name = "";
            startData = parseMessage.indexOf("<Name>")+6;
            endData = parseMessage.indexOf("</Name>",startData);
            if(endData >= 0 && endData < endEntity)name = 
                parseMessage.substring(startData, endData);
            milOrg.setName(name);

            // Hostility - get Side then pull from hostilityMap
            String side = "";
            startData = parseMessage.indexOf("<Side>")+6;
            endData = parseMessage.indexOf("</Side>",startData);
            if(endData >= 0 && endData < endEntity)side = 
                parseMessage.substring(startData, endData);
            String hostility = hostilityMap.get((Object)side);
            if(hostility == null)hostility = "UNK";
            milOrg.setHostility(hostility);

            // Latitude
            String latitude = "";
            startData = parseMessage.indexOf("<Latitude>")+10;
            endData = parseMessage.indexOf("</Latitude>",startData);
            if(endData >= 0 && endData < endEntity)latitude = 
                parseMessage.substring(startData, endData);
            milOrg.setLatitude(latitude);

            // Longitude
            String longitude = "";
            startData = parseMessage.indexOf("<Longitude>")+11;
            endData = parseMessage.indexOf("</Longitude>",startData);
            if(endData >= 0 && endData < endEntity)longitude = 
                parseMessage.substring(startData, endData);
            milOrg.setLongitude(longitude);

            // Symbol Identifier
            String symbolIdentifier = "";
            startData = parseMessage.indexOf("<SIDCString>")+12;
            endData = parseMessage.indexOf("</SIDCString>",startData);
            if(endData >= 0 && endData < endEntity)symbolIdentifier = 
                parseMessage.substring(startData, endData);
            milOrg.setSymbolIdentifier(symbolIdentifier);
      
            // if we didn't get hostility from initialization message,
            // take it from the symbolIdentifier
            if(hostility.equals("UNK")){
                String hostilityChar = symbolIdentifier.substring(1,2); 
                if(hostilityChar.equals("F"))hostility = "FR";
                if(hostilityChar.equals("H"))hostility = "HO";
                milOrg.setHostility(hostility);
            }

            // add it to the hashmap and graphic map
            bml.addUnit(milOrg.uuid, milOrg);
            if(uuid.length() > 0 && name.length() > 0 && hostility.length() > 0 &&
                latitude.length() > 0 && longitude.length() > 0)
                bml.drawLocation(null, null, null, -2, -2, milOrg);

            // move to next Entity
            startEntity = parseMessage.indexOf("<Entity>",endEntity)+8;
            entityCount++;

        }// end while(startName > 0) 
              
        bml.initStatusLabel.setText(Integer.toString(entityCount));
        return entityCount;
        
    }// end parseC2SIMInit()
    
}// end class MilOrg
