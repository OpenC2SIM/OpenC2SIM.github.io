Orders in this directory, with exception of the ASX Order, have been 
converted from the schema used in MSG-145 2019 MiniEx to the new 
C2SIM_ASX_LOXv1.0.0 schema associated with C2SIM Standard v1.0.0. 
