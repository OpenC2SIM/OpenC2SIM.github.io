/*----------------------------------------------------------------*
|    Copyright 2022 Networking and Simulation Laboratory          |
|     C4I Center, George Mason University, Fairfax, Virginia      |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for academic purposes is hereby  |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

package edu.gmu.c4i.swc2s;
import edu.gmu.c4i.swclient.SW_RESTClient;

import java.util.UUID;
import java.io.BufferedReader;
import java.io.FileReader;
import java.net.URI;
import javax.ws.rs.core.Response;
import org.jdom2.Document;
import org.json.JSONArray;
import org.json.JSONML;
import org.json.JSONObject;
import org.json.XML;
import edu.gmu.c4i.c2simclientlib2.*;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.LineSeparator;
import org.jdom2.output.XMLOutputter;
import edu.gmu.c4i.swc2s.C2SIM_Util.*;

/**
 *
 * SWC2S C2SIM Interface to SitaWare 
    Process C2SIM Initialization message.  Create units (Symbols) on SitaWare werver
    Process position reports from C2SIM Server Update position in Sitaware
 */
/**

@author Douglas Corner - George Mason University C4I/Cyber Center
*/
public class SWC2S_Main extends Thread {


    static SWInterface sw;
    
    static String c2simHost;
    static String swHost = "";
    static String swUser = "";
    static String swPW = "";

    static String c2simDateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    static SimpleDateFormat sdf = new SimpleDateFormat(c2simDateFormat);
    
    // Map unit name to symbol
    public static HashMap<String, JSONObject> nameToSymbol = new HashMap<>();
    
    // Map unit name to UUID
    public static HashMap<String, String> nameToUUID = new HashMap<>();
    
    // Map UUID to name
    public static HashMap<String, String> uuidToName = new HashMap<>();

    // Logon Information
    static String user = "";
    static String pw = "";

    /************/
    /*  main    */
    /************/
    /**
    
    @param args - Command line arguments
        args[0] - C2SIM Host address
        args[1] - Sitaware Host address
        args[2] - Sitaware user account
        args[3] - Sitaware user password        
    @throws Exception 
    */
    public static void main(String[] args) throws Exception {
        
        // Process runtime arguments
        
        if (args.length != 4) {
            System.out.println("Usage - SW2C2SIM_Main C2SIM_Host  Sitaware_Host Sitaware_account SItaware_PW");
            System.exit(1);
        }
        
        // Get parameters from command line
        c2simHost = args[0];
        swHost = args[1];
        swUser = args[2];
        swPW = args[3];


        // Start the thread that listens for C2SIM reports
        C2SIM_Reports r = new C2SIM_Reports(c2simHost, swHost, swUser, swPW);
        r.start();

        // Start the thread that listens for Sitaware Orders
        C2SIM_Orders o = new C2SIM_Orders(c2simHost, swHost, swUser, swPW);
        o.start();
        
        // Just hang around
        while (true) {
            Thread.sleep(1000);
        }

    }   // main()
}   // class SW2C2SIM_Main


