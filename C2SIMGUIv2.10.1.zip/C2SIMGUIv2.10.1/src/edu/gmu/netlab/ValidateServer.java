/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.netlab;

import edu.gmu.c4i.c2simclientlib2.C2SIMClientException;
import edu.gmu.c4i.c2simclientlib2.C2SIMClientREST_Lib;
import static edu.gmu.netlab.C2SIMGUI.bml;
import static edu.gmu.netlab.C2SIMGUI.printError;
import java.io.BufferedWriter;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.FileReader;
import java.io.BufferedReader;

/**
 * C2SIM Server Validation Option for C2SIMGUI
 *
 * This is based on a now-defunct quality assurance tool the GMU C4I & Cyber Center 
 * developed several versions back. The idea is that after software changes are made, 
 * the tool will run a list of transactions (files in a directory that user selects), 
 * obtain the responses, and compare to set of files in another directory that 
 * contain correct responses. Output to console will be one line per file, giving 
 * input and output filenames and any error where output is not as expected. This 
 * is the best test we know of to confirm that changes to server software did not 
 * break some previous function.
 * 
 * The output will appear on the GUI command-line console and also will be copied 
 * into a file named for date-time of the test.
 * 
 * A configuration parameter will set the length of time to wait for all STOMP 
 * output to be received (if translation is running there can be multiple XML files)
 * 
 * Input is contained in .txt files in the ValidateServer directory. Each line
 * in each file causes one test transaction. The line contains either a server
 * command (such as STOP) or PUSH with a filename for XML file to push, which
 * will be contained in subdirectory SendXML.
 * 
 * Test should be run when there is no other server traffic.
 * 
 * 1. for each file in ValidateServer/Scripts directory, in order by filename:
 * 
 * - for comment lines (starting with #) output the line in result file and ignore
 * 
 * - script lines for server commands cause issue of a PUSH to server REST input 
 *   and capture of the HTTP response XML
 *   * the response will be written in a file Of the same name plus -RESPONSE in 
 *     the ResponseXML subdirectory
 *   * server commands are STOP, RESET, INITIALIZE, SHARE and START
 *   * for success the response must not contain ERROR
 *   * and server must be in RUNnING state
 * 
 * - the other type of script is PUSH, which provides the type of a C2SIM 
 *   document to be pushed (one of INIT, C2SIMORDER, C2SIMREPORT, CBMLORDER, 
 *   CBMLREPORT, IBMLORDER or IBMLREPORT) followed by the filename to be pushed,
 *   which must be in subdirectory SendXML and then, optionally one or two
 *   translated formats expect to follow a copy of the pushed file (the possible
 *   formats are C2SIM, CBML and IBML)
 *   * validation will submit the file by REST and capture both the HTTP response 
 *     (placed in subdirectory ResponseXML, with -RESPONSE appended to input 
 *     filename) and the XML coming from server STOMP (placed in subdirectory 
 *     ReceiveXML, with format appended to its name)
 *   * for success, the HTTP response must not contain ERROR and the contents of 
 *     the STOMP XML output must match the contents of the file of same name in 
 *     the CompareXML subdirectory 
 *   * we suggest that the file placed in CompareXML for comparison should be one 
 *     that was received from the server, as a correct returned file might have 
 *     differences in whitespace
 *   * files in CompareXML must have format (e.g. -C2SIMORDER) as added to name, 
 *     before .xml)
 * 
 *-  for each format received, an out line will include length of time until 
 *   that format is received (up to a configured limit) and the name of file 
 *   containing response
 * 
 * 2. At end of validation run, the number of files passed, failed and total 
 * is output; also count of failed transactions by type of failure; the output
 * information also will be written in a .txt file with date-time in its name,
 * in subdirectory ValidationResults.
 *
 * @author JMP 15May2020
 */
public class ValidateServer {
    
    C2SIMGUI bml = C2SIMGUI.bml;
    InitC2SIM initC2SIM = new InitC2SIM();
    String workingDirectory;
    File printResults, inputXML, outputXML, responseXML, compareXML, 
        validationResults, scripts, thisScript;
    BufferedWriter writeResults;
    String[] scriptList;
    String scriptLine;
    String filename;
    int numberOfFormats = 3;
    
    // statistics
    int stopOK = 0;
    int stopError = 0;
    int resetOK = 0;
    int resetError = 0;
    int initializeOK = 0;
    int initializeError = 0;
    int shareOK = 0;
    int shareError = 0;
    int startOK = 0;
    int startError = 0;
    int initOK = 0;
    int initError = 0;
    int[][] countOrderOK = new int
       [3] // from:{C2SIM,CBML,IBML}
       [3];// to:  {C2SIM,CBML,IBML}
   int[][] countOrderError = new int
       [3] // from:{C2SIM,CBML,IBML}
       [3];// to:  {C2SIM,CBML,IBML}
   int[][] countReportOK = new int
       [3] // from:{C2SIM,CBML,IBML}
       [3];// to:  {C2SIM,CBML,IBML}
   int[][] countReportError = new int
       [3] // from:{C2SIM,CBML,IBML}
       [3];// to:  {C2SIM,CBML,IBML}

    /**
     * runs a ServerValidation per the above description
     */
    void runTest(){
        
        // ask user to confirm test is to be run
        int answer = JOptionPane.showConfirmDialog(
                    null,  
                    "ARE YOU SURE YOU WANT TO RUN SERVER VALIDATION?"+
                        "\n(IF SO MAKE SURE THERE IS NO OTHER SERVER USE NOW)", 
                    "Test server warning",
                    JOptionPane.OK_CANCEL_OPTION);
                if (answer != JOptionPane.OK_OPTION) {
                    return;
                }
        bml.runningServerTest = true;  
        
        // make sure we have required subdirecttories:
        // SendXML, ReceiveXML, ResponseXML, CompareXML, ValidationResults
        workingDirectory = 
            bml.guiFolderLocation + bml.delimiter + "ValidateServer" + bml.delimiter;
                
        // directory ValidationResults - make if not present
        validationResults = new File(workingDirectory + "ValidationResults");
        if(!validationResults.exists())
            validationResults.mkdir(); 
        
        // File to hold results of this run - must be new
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HHmmss");
        Date nowDate = new Date();
        String outDate = sdf.format(nowDate);
        printResults = new File(
            validationResults,
            "validationResults-" + outDate + ".txt");
        try{
            FileWriter fileWriter = new FileWriter(printResults);
            writeResults = new BufferedWriter(fileWriter);
        }
        catch(IOException ioe) {
             bml.showErrorPopup(
                "error opening file to write results:" + ioe, 
                "Making results file");
            ioe.printStackTrace();
            bml.runningServerTest = false;
            return;
        }
        
        // directory SendXML must exist
        inputXML = new File(workingDirectory + "SendXML");
        if(!inputXML.isDirectory()){
            bml.showErrorPopup(
                "can't run Server Validation - directory ValidateServer/SendXML not found",
                "Directory error");
            bml.runningServerTest = false;
            return;
        }
        
        // directory ReceiveXML - make if not present
        outputXML = new File(workingDirectory + "ReceiveXML");
        if(!outputXML.exists())
            outputXML.mkdir();
        
        // directory ResponseXML - make if not present
        responseXML = new File(workingDirectory + "ResponseXML");
        if(!responseXML.exists())
            responseXML.mkdir();
        
        // directory CompareXML - must exist
        compareXML = new File(workingDirectory + "CompareXML");
        if(!compareXML.isDirectory()){
            bml.showErrorPopup(
                "can't run Server Validation - directory ValidateServer/CompareXML not found",
                "Directory error");
            outputLine("can't run Server Validation - directory ValidateServer/CompareXML not found");
            bml.runningServerTest = false;
            return;
        }        
        
        // direcctory Scripts - must exist
        scripts = new File(workingDirectory + "Scripts");
        if(!scripts.isDirectory()){
            bml.showErrorPopup(
                "can't run Server Validation - directory ValidateServer/Scripts not found",
                "Directory error");
            outputLine("can't run Server Validation - directory ValidateServer/Scripts not found");
            bml.runningServerTest = false;
            return;
        }
        scriptList = scripts.list();
        
        // announce ourself in output and print directories to be used
        outputLine("------C2SIM SERVER VALIDATION (DATE-TIME " + outDate + ")------");
        outputLine("XML input comes from:" + inputXML.getName());
        outputLine("XML output goes to:" + outputXML.getName());
        outputLine("Server response XML goes to:" + responseXML.getName());
        outputLine("Correct XML for comparison comes from:" + compareXML.getName());
        outputLine("List of results goes in file:" + printResults.getName());
        outputLine("  which file goes in:" + validationResults.getName());
        outputLine("Validation scripts come from:" + scripts.getName());
        outputLine("-------------------");
        
        // process every script in the Scripts directory
        for(int scriptNumber = 0;
            scriptNumber < scriptList.length;
            ++scriptNumber){
            
            // open the script
            String scriptFullname = 
                workingDirectory + "Scripts" + bml.delimiter + 
                    scriptList[scriptNumber];
            outputLine("Running script:" + scriptList[scriptNumber]);
            int timesToRun = bml.serverTestStompWait/1000;
            outputLine("   response will be monitored up to "+timesToRun+
                " seconds for each XML file pushed to server");
            BufferedReader scriptFileReader;
            try{
                scriptFileReader = 
                    new BufferedReader(new FileReader(scriptFullname));
                
                // process all lines in the script one at a time
                while(true){
                         
                    // read next script line
                    scriptLine = scriptFileReader.readLine();
                    if(scriptLine == null)break;
                    if(!scriptLine.equals(""))
                        outputLine("SCRIPT LINE:" + scriptLine);

                    // process the script line
                    String unmodifiedLine = scriptLine;
                    String action = getNextToken();
                    if(action == null)break;
                    String pushResponse = "";
                    if(!action.equals("")){
                        if(action.equals("STOP")){
                            pushResponse = initC2SIM.pushStopC2SIM();
                            if(pushResponse.contains("ERROR"))++stopError;
                            else ++stopOK;
                        }
                        else if(action.equals("RESET")){
                            pushResponse = initC2SIM.pushResetC2SIM();
                            if(pushResponse.contains("ERROR"))++resetError;
                            else ++resetOK;
                        }
                        else if(action.equals("INITIALIZE")){
                            pushResponse = initC2SIM.pushInitializeC2SIM();
                            if(pushResponse.contains("ERROR"))++initializeError;
                            else ++initializeOK;
                        }
                        else if(action.equals("SHARE")){
                            pushResponse = initC2SIM.pushShareC2SIM();
                            if(pushResponse.contains("ERROR"))++shareError;
                            else ++shareOK;
                        }
                        else if(action.equals("START")){
                            pushResponse = initC2SIM.pushStartC2SIM();
                            if(pushResponse.contains("ERROR"))++startError;
                            else ++startOK;
                        }
                        else if(action.equals("PUSH")){
                            String format = getNextToken();
                            filename = getNextToken();
                            String format2 = getNextToken();
                            String format3 = getNextToken();
                            // check for incomplete PUSH script line
                            if(format == null ||filename == null){
                                outputError("in script line:" + unmodifiedLine);
                                continue;
                            }
                            
                            // check for existence of file
                            String fullFilename = workingDirectory + "SendXML" + 
                                bml.delimiter + filename;
                            if(!(new File(fullFilename)).exists()){
                                outputError("can't find file in SendXML:" + 
                                    filename);
                                continue;
                            }
                             
                            // create filenames in ReceiveXML and CompareXML
                            if(format2 == null)format2 = "";
                            if(format3 == null)format3 = "";
                            String type = "";
                            if(format.endsWith("ORDER"))type = "ORDER";
                            if(format.endsWith("REPORT"))type = "REPORT";
                            
                            // main format is run every time
                            String mainOutput = 
                                combineFilename(format, "ReceiveXML");
                            String mainCompare = 
                                combineFilename(format, "CompareXML");
                            String secondFormat = "";
                            String secondOutput = "";
                            String secondCompare = "";
                            String thirdFormat = "";
                            String thirdOutput = "";
                            String thirdCompare = "";
                            
                            // replace unused formats with empty strings
                            if(!format.equals("INIT")){
                                if(format2.length() == 0){
                                    secondFormat = "";
                                    secondOutput = "";
                                    secondCompare = "";
                                }
                                else
                                {
                                    secondFormat = format2 + type;
                                    secondOutput = 
                                        combineFilename(secondFormat, "ReceiveXML");
                                    secondCompare = 
                                        combineFilename(secondFormat, "CompareXML");
                                }
                                if(format3.length() == 0){
                                    thirdFormat = "";
                                    thirdOutput = "";
                                    thirdCompare = "";   
                                }
                                else
                                {
                                    thirdFormat = format3 + type;
                                    thirdOutput = 
                                        combineFilename(thirdFormat, "ReceiveXML");
                                    thirdCompare = 
                                        combineFilename(thirdFormat, "CompareXML"); 
                                }
                            }
                            
                            // files to come in ReceiveXML for this script line
                            File testMain = new File(mainOutput);
                            File testSecond = new File(secondOutput);
                            File testThird = new File(thirdOutput);

                            // delete old ReceiveXML files
                            (new File(mainOutput)).delete();
                            (new File(secondOutput)).delete();
                            (new File(thirdOutput)).delete();
                        
                            // issue PUSH matching format
                            if(format.equals("INIT")){  
                                pushResponse = pushXml("C2SIM", filename);
                                type = "";
                            }
                            else if(format.equals("C2SIMORDER")){
                                pushResponse = pushXml("C2SIM", filename);
                                type = "ORDER";
                            }
                            else if(format.equals("C2SIMREPORT")){
                                pushResponse = pushXml("C2SIM", filename);
                                type = "REPORT";
                            }
                            else if(format.equals("CBMLORDER")){
                                pushResponse = pushXml("BML", filename);
                                type = "ORDER";
                            }
                            else if(format.equals("CBMLREPORT")){
                                pushResponse = pushXml("BML", filename);
                                type = "REPORT";
                            }
                            else if(format.equals("IBMLORDER")){
                                pushResponse = pushXml("BML", filename);
                                type = "ORDER";
                            }
                            else if(format.equals("IBMLREPORT")){
                                pushResponse = pushXml("BML", filename);
                                type = "REPORT";
                            }
           
                            // check for server OK
                            if(pushResponse.contains("ERROR")){
                                outputLine("format "+format+" server push response ERROR");
                                collectStats(false, format, format, type);
                                continue;
                            }
                            // Initialize is not distributed
                            else if(format.equals("INIT"))++initOK;
                            if(format.equals("INIT"))continue;
                            
                            // Subscriber class will write the ReceiveXML files
                            // test once per second until they all arrive
                            // or bml.serverTestStompWait seconds expire
                            System.out.println("listening for receive of XML:");
                            try{
                                for(int iterations = 0;
                                    iterations < timesToRun;
                                    iterations++){
                                    Thread.sleep(1000);// one second
                                    System.out.print(iterations+" ");// console only
                                    if(testMain.exists())
                                        if((format2.length() == 0) || testSecond.exists())
                                            if((format3.length() == 0) || testThird.exists())
                                                break;
                                }// end for...
                                System.out.println("");
                            }
                            catch(InterruptedException ie){}
                            
                            // confirm that we have a file to compare
                            if(noCompareFile(mainOutput))continue;
                            if(noCompareFile(secondOutput))format2 = "";
                            if(noCompareFile(thirdOutput))format3 = "";
                            
                            // compare files in ReceiveXML with same name in CompareXML
                            // INIT does not produce a response
                            if(format.equals("INIT"))continue;
                            if(!(new File(mainOutput)).exists()){
                                outputLine("  -no output of format " + format + " received");
                                collectStats(false, format, format, type);
                            }
                            else collectStats(
                               compareFiles(mainOutput, mainCompare, format), format, format, type);
                            if(format2.length()>0)if(!(new File(secondOutput)).exists()){
                                outputLine("  -no output of format " + format2 + " received");
                                collectStats(false, format, format2, type);   
                            }
                            else collectStats(
                                compareFiles(secondOutput, secondCompare, format2), format, format2, type);
                            if(format3.length()>0)if(!(new File(thirdOutput)).exists()){
                                outputLine("  -no output of format " + format3 + " received");
                                collectStats(false, format, format3, type);   
                            }
                            else collectStats(
                                compareFiles(thirdOutput, thirdCompare, format3), format, format3, type);
                            
                        }// end else if(action.equals("PUSH"))
                    }//end if(!action...
                }// end while(true)
            }catch(IOException ioe) {
                bml.showErrorPopup(
                    "error reading file: Scripts/" + scriptList[scriptNumber], 
                    "Script file");
                ioe.printStackTrace();
                break;
            }
                
        }// end for(int scriptNumber = 0;
                
        // output stats
        int send;
        String[] rowLabel = {"C2SIM","CBML ","IBML "};
        outputLine("-------------------");
        outputLine("RESULTS OF VALIDATION:");
        outputLine(" ");
        outputLine("Server Commands OK/Error");
        outputLine("STOP:       " + stopOK +"/" + stopError);
        outputLine("RESET:      " + resetOK +"/" + resetError);
        outputLine("INITIALIZE: " + initializeOK +"/" + initializeError);
        outputLine("SHARE:      " + shareOK +"/" + shareError);
        outputLine("START:      " + shareOK +"/" + shareError);
        outputLine(" ");
        outputLine("C2SIM Initialization OK/Error:");
        outputLine("INIT        " + initOK + "/" + initError);
        outputLine(" ");
        outputLine("Order distribution and translation OK/Error:");
        outputLine("vertical is send; horizontal is receive");
        outputLine("       C2SIM  CBML  IBML");
        for(send = 0; send < numberOfFormats; ++send){
            outputLine(rowLabel[send]+    
                  "   "+countOrderOK[send][0]+"/"+countOrderError[send][0]+
                  "   "+countOrderOK[send][1]+"/"+countOrderError[send][1]+
                  "   "+countOrderOK[send][2]+"/"+countOrderError[send][2]);     
        }
        outputLine(" ");
        outputLine("Report distribution and translation OK/Error:");
        outputLine("vertical is send; horizontal is receive");
        outputLine("       C2SIM  CBML  IBML");
        for(send = 0; send < numberOfFormats; ++send){
            outputLine(rowLabel[send]+    
                  "   "+countReportOK[send][0]+"/"+countReportError[send][0]+
                  "   "+countReportOK[send][1]+"/"+countReportError[send][1]+
                  "   "+countReportOK[send][2]+"/"+countReportError[send][2]);
        }
        outputLine(" ");

        // mark end of this script
        outputLine("-------------------");
         
        // close the results file
        try{
            writeResults.close();
        }
        catch(IOException ioe) {
            bml.showErrorPopup(
                "error closing results file:" + ioe, 
                "Closing results file");
            ioe.printStackTrace();
        }// end close writeResults
        
        // print collected statistics
        
        bml.runningServerTest = false;
        
    }// end runTest()
    
    /**
     * pulls blank-separated tokens from left end of s String
     * returns the token and remove it from scriptLine as a side-effect
     * returns null if no more tokens
     */
    String getNextToken(){
        
        if(scriptLine.equals(""))return null;
        int tokenEnd = scriptLine.indexOf(' ');
        String token = "";
        if (tokenEnd < 0) {
            token = scriptLine;
            scriptLine = "";
        }
        else {
            token = scriptLine.substring(0,tokenEnd);
            scriptLine = scriptLine.substring(tokenEnd+1);
        }
        if(token.endsWith(".xml"))return token;
        return token.toUpperCase();
        
    }// end getNextToken()
    
    /**
     * displays a line of output and also writes it to file printResults
     * returns true on IOError
     */
    boolean outputLine(String lineToPrint){
        try{
            writeResults.write(lineToPrint);
            writeResults.newLine();
        }
        catch(IOException ioe) {
            System.out.println("ERROR in ValidateServer:" +
                "file error writing results:" + ioe.getMessage());
            return true;
        }
        System.out.println(lineToPrint);
        return false;
    }// end outputLine()
    
    /**
     * checks whether comparison file exists
     * returns true for failure
     */
    boolean noCompareFile(String filename){
        String testShortname = (new File(filename)).getName();
        String compareFilename = workingDirectory + "CompareXML" + 
            bml.delimiter + testShortname; 
        if(!(new File(compareFilename)).exists()){
            outputLine("   CONFIGURATION ERROR:file "+filename+
                " is not present in CompareXML for comparison");
            outputLine("   put a copy of a good received XML file there");
            outputLine("   be sure to include format such as -C2SIMORDER before .xml");
            return true; 
        }
        return false;
    }
    
    /**
     * compare contents of two files with message to outputLine
     * returns true if file contents match exactly
     */
    boolean compareFiles(String outputFilename, String compareFilename, String format){
       
        // verify we have a matching file in CompareXML
        if(!(new File(compareFilename)).exists()){
            outputLine("   CONFIGURATION ERROR:file "+filename+
                " is not present in CompareXML for comparison");
            outputLine("   put a copy of matching good received XML file there");
            outputLine("   be sure to include format such as -C2SIMORDER before .xml");
            return false;
        }
        
        // compare the files contents
        String xml1 = bml.readAnXmlFile(outputFilename);
        String xml2 = bml.readAnXmlFile(compareFilename);
        if(xml1.equals(xml2)){
            outputLine("  -"+format+" received file matches reference");
            return true;
        }
        else {
            outputLine("  -"+format+" received file does not match reference");
            return false;
        }
    }// end compareFiles()
    
    /**
     * collect statistics on success and failure of Orders
     */
    void collectStats(boolean success, String sendFormat, String receiveFormat, String type){
        
        // deal with INIT as a special case
        if(sendFormat.equals("INIT")){
            if(success)initOK++;
            else initError++;
            return;
        }
        
        // assume if not an Order it must be Report
        if(type.equals("ORDER")){
            if(success)++countOrderOK[formatNumber(sendFormat)][formatNumber(receiveFormat)];
            else ++countOrderError[formatNumber(sendFormat)][formatNumber(receiveFormat)];
        } else {
            if(success)++countReportOK[formatNumber(sendFormat)][formatNumber(receiveFormat)];
            else ++countReportError[formatNumber(sendFormat)][formatNumber(receiveFormat)];
        }
    }
    
    /**
     * convert the formats to number to index the statistics matrix
     * returns the index
     */
    int formatNumber(String format){
        if(format.startsWith("C2SIM"))return 0;
        if(format.startsWith("CBML"))return 1;
        if(format.startsWith("IBML"))return 2;
        outputLine("internal error - " + format + " not a usable code");
        return -1;
    }
    
    /**
     * write and output line with ERROR before text
     */
    void outputError(String lineToPrint){
        outputLine("ERROR in ValidateServer:" + lineToPrint);
    }
    
    /**
     * creates a String from current filename being processed, with
     * type code (INIT, C2SIMORDER, ...) inserted before .xml,
     * located in designated subdirectory
     */
    String combineFilename(String docType, String subdirectory){
        return workingDirectory + subdirectory + 
            bml.delimiter + filename.substring(0,filename.length()-4) +
            "-" + docType + ".xml";
    }
    String outputFilename(String docType){
        return combineFilename(docType, "ReceiveXML");
    }
    
    /**
     * write an XML string of current file, as returned by server,
     * to ReceiveXML directory - this is invoked from Subscriber call
     * input parameter is type of document as detected by 
     * Subscriber.interpretMessage() - it is appended to filename
     */
    void writeOutputXml(String xmlDocument, String docType){
        String outputFilename = outputFilename(docType);
        outputLine("  -received XML file:" + outputFilename);
        try{
            BufferedWriter out = new BufferedWriter(
                new FileWriter(outputFilename));
            out.write(xmlDocument);
            out.close();
        }
        catch(IOException ioe){
            outputError("IOException in ValidateServer writing XML:" +
                ioe.getMessage());
        }
    }// end writeOutputXml()
    
    /**
     * send an XML document to server REST input and return its response
     */
    String pushXml(String docType, String xmlFilename)throws IOException {
        
        // check that it is an XML file
        if(!xmlFilename.endsWith("xml")){
             outputError("invalid file to PUSH - must be XML"); 
            return null;
        }
                
        // open connection to REST server
        if(bml.submitterID.length() == 0) {
            outputError("cannot push C2SIM INIT - submitterID Config required");
            return null;
        }
        
        // instantiate a client using ClientLib
        C2SIMClientREST_Lib c2simClient = 
            new C2SIMClientREST_Lib(
                "BMLC2GUI@"+bml.localAddress,
                bml.serverName,
                "INFORM");// performative for Initialize
        c2simClient.setHost(bml.serverName);
        c2simClient.setSubmitter(bml.submitterID);
        c2simClient.setPath("C2SIMServer/c2sim");
        c2simClient.setProtocol(docType);
	
        // read and push C2SIM from the parameter file
        FileReader xmlFile;
        String pushInputString = "";
        try{
          xmlFile=new FileReader(
              workingDirectory + "SendXML" + bml.delimiter + xmlFilename);
          int charBuf; 
          while((charBuf = xmlFile.read())>0) {
            pushInputString += (char)charBuf;
          }
        }
        catch(Exception e) {
          bml.printError("Exception in reading XML file " +xmlFilename + ":"+e);
          e.printStackTrace();
          return null;
        }
        
        // send the input; set pushingInitialize so can use with INIT
        // (does not affect other types)
        String pushResponseString = "";
        bml.pushingInitialize = true;
        try{
            pushResponseString = 
                c2simClient.bmlRequest(pushInputString);
        } catch (C2SIMClientException bce) {
            bml.showErrorPopup( 
                "exception pushing XML document:" +
                    bce.getMessage()+" cause:" + bce.getCauseMessage(), 
                "C2SIM XML Document Push");
            bml.pushingInitialize = false;
            return null;
        }
        
        // write result to file
        String responseFilename = xmlFilename.substring(0,xmlFilename.length()-4) + 
            "-RESPONSE.xml";
        (new File(workingDirectory + "ResponseXML/" + responseFilename)).delete();
        BufferedWriter out = 
            new BufferedWriter(
                new FileWriter(workingDirectory + "ResponseXML/" + responseFilename));
        out.write(pushResponseString);
        out.close();
        bml.pushingInitialize = false;
        return pushResponseString;
        
    }// end pushXml()
    
}// end class ValidateServer
