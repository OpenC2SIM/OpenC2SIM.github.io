
NOTE: The DIS version has not been tested; HLA version is believed to work properly with VRForces 5.0.1a running task-follows-task, no matter which order the Tasks are submitted in C2SIM Orders.