/*----------------------------------------------------------------*
|   Copyright 2020 Networking and Simulation Laboratory           |
|         George Mason University, Fairfax, Virginia              |
|                                                                 |
| Permission to use, copy, modify, and distribute this            |
| software and its documentation for all purposes is hereby       |
| granted without fee, provided that the above copyright notice   |
| and this permission appear in all copies and in supporting      |
| documentation, and that the name of George Mason University     |
| not be used in advertising or publicity pertaining to           |
| distribution of the software without specific, written prior    |
| permission. GMU makes no representations about the suitability  |
| of this software for any purposes.  It is provided "AS IS"      |
| without express or implied warranties.  All risk associated     |
| with use of this software is expressly assumed by the user.     |
*----------------------------------------------------------------*/

Functional description from Curt Blais 15 May 2020:

keep group statements together:

	<xs:sequence>
		<xs:group ref="ActionGroup "/>
		<xs:group ref="TaskGroup "/>
		<xs:element ref="RuleOfEngagement" minOccurs="0" maxOccurs="unbounded"/>
		<xs:element ref="TaskFunctionalRelation" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>

Progranner commments:
* Post-processor to revise an XML Schema (XSD) file by reordering
 * as necessary such that all complex types using "sequence" and 
 * "choice" have all of their elements sequenced in alphanumeric order,
 * with "group" instances followed by "element" instances.

input: schema.xsd file
 * output: revised schema.xsd with complex types reordered but not other change
 * command line parameters:
 *  0. input filename in the invoking directory or path-filename
 *  1. input filename in the invoking directory or path-filename
 *  2. optionally, namespace prefix; defaults to xs

To run in Windows double-click runAlphabetize.bat

To in MacOS X open a command window, cd to C2SIMAlphabetize and type ./runAlphabetize

JARfile is in subdirectory dist and includes the Java code

