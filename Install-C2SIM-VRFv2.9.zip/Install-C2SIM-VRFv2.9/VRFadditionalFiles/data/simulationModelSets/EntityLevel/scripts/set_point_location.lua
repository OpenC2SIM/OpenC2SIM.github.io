-- Set the location of the point. This script makes it possible to send
-- a control point a message to change its location. Useful in Lua scripts.

-- Set Parameters Available in Script
--  setParameters.altitudeAgl Type: Location3D - The new location for the graphic

myLoc = this:getLocation3D()
terrainHeight = vrf:getTerrainAltitude(
   myLoc:getLat(), myLoc:getLon())
myLoc:setAlt(terrainHeight + setParameters.altitudeAgl)
this:setLocation3D(myLoc)

-- Called when the task first starts. Never called again.
function init()

   vrf:endSet()
end

-- Called each tick while this task is active.
function tick()
end
